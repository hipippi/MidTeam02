$(function () {    	
	const btnPopupSchedule = document.getElementById('btnPopupSchedule');
	const popupSchedule = document.getElementById('popupSchedule');
	const btnCloseSchedule = document.getElementById('btnCloseSchedule');
	const btnApplySchedule = document.getElementById('btnApplySchedule');
	let modalBackdrop = null; 
	
	btnPopupSchedule.addEventListener("click", function (e) {
	  e.preventDefault();
	  openPopup()	  
	});
	
	btnCloseSchedule.addEventListener("click", function (e) {
	  e.preventDefault();
	  closePopup(); 
	});
	
	

	
function openPopup(){
  if (!modalBackdrop) {
	modalBackdrop = document.createElement('div');
	modalBackdrop.className = 'modal-backdrop fixed inset-0 flex items-center justify-center z-50';
	document.body.appendChild(modalBackdrop);
	popupSchedule.style.display = 'block';   
	modalBackdrop.appendChild(popupSchedule);
	document.body.classList.add('overflow-hidden'); 	
  }
}
function closePopup() {
  popupSchedule.style.display = 'none';

  if (modalBackdrop) {
    document.body.removeChild(modalBackdrop);
    modalBackdrop = null;
    document.body.classList.remove('overflow-hidden'); 
  }
}


  function getNowString() {
    var now = new Date();
    var yyyy = now.getFullYear();
    var mm = ('0' + (now.getMonth() + 1)).slice(-2);
    var dd = ('0' + now.getDate()).slice(-2);
    var HH = ('0' + now.getHours()).slice(-2);
    // 10분 단위로 내림
    var minute = now.getMinutes();
    var MM = ('0' + (Math.floor(minute / 10) * 10)).slice(-2);
    return yyyy + '-' + mm + '-' + dd + ' ' + HH + ':' + MM;    
  }

  $('#popup_start_datetime').val(getNowString());
  $('#popup_end_datetime').val(getNowString());

  $('#popup_start_datetime').datetimepicker({   
    dateFormat: "yy-mm-dd",
    timeFormat: "HH:mm",
    controlType: 'select',
    oneLine: true,
    showTimepicker: true,
    stepMinute: 10, // 10분 단위로 설정
    onSelect: function(datetimeText) {
    	console.log("start_datetime:"+datetimeText);
	    $(this).val(datetimeText); // 수동으로 value에 값 넣기
	},
    onClose: function(selectedDateTime) {
      // 시작일시 변경 시 종료일시가 더 빠르면 종료일시를 시작일시로 맞춤
      if ($('#popup_end_datetime').val() < selectedDateTime) {
        $('#popup_end_datetime').val(selectedDateTime);
      }
    }
  });

  $('#popup_end_datetime').datetimepicker({
    dateFormat: "yy-mm-dd",
    timeFormat: "HH:mm",
    controlType: 'select',
    //controlType: 'slider',
    oneLine: true,
    stepMinute: 10, // 10분 단위로 설정
    beforeShow: function(input, inst) {
      // 종료일시 팝업이 열릴 때마다 시작일시 값을 읽어 제한 적용
      var startVal = $('#popup_start_datetime').val();
      if (startVal) {
        // minDate만 사용 (minDateTime은 사용하지 않음)
        $(this).datetimepicker('option', 'minDate', startVal);
      }
    },
    onSelect: function(datetimeText) {
    	console.log("popup_end_datetime:"+datetimeText);
	    $(this).val(datetimeText); // 수동으로 value에 값 넣기
	}
  });
  
  // 팝업 저장 -> 부모 form의 hidden input에 값 복사
	btnApplySchedule.addEventListener('click', () => {
		
		document.getElementById('scheduleWidget').style.display = 'block';
		let valueScheduleTitle = document.getElementById('popup_schedule_title').value;
		let valueStartDatetime = document.getElementById('popup_start_datetime').value;
		let valueEndDatetime = document.getElementById('popup_end_datetime').value;
		let valueMemo = document.getElementById('popup_memo').value;
		console.log(valueScheduleTitle);
	  document.getElementById('schedule_title').value = valueScheduleTitle;
	  document.getElementById('schedule_title_txt').textContent= valueScheduleTitle;
	  document.getElementById('start_datetime').value = valueStartDatetime;
	   document.getElementById('start_datetime_txt').textContent = valueStartDatetime;	   
	  document.getElementById('end_datetime').value = valueEndDatetime;
	  
	  //document.getElementById('end_datetime_txt').textContent = valueEndDatetime;
	  document.getElementById('memo').value = valueMemo;	
	  
	
	  closePopup();
	});	
});
