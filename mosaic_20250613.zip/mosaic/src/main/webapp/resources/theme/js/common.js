/*
*	common.js
*	공통 요소 스크립트. jquery 가능
*/
document.addEventListener("DOMContentLoaded", function () {
	
	/*
	const shareBtn = document.getElementById("shareButton");	
	shareBtn.addEventListener("click", function (e) {
		const sharePopup = document.getElementById("sharePopup");
		console.log("공유버튼 클릭");
		//isActive = !isActive;         
        sharePopup.classList.toggle("hidden");
	});
	*/


	$('#fullLangSelect').change(function() {
		console.log("fullLangSelect Changed");
		var targetLang = $(this).val();
		console.log("fullLang targetLang:"+targetLang);
		if (!targetLang) return;
	
	    const nodeList = [];
	    const originalTexts = [];
	
	    // body 내부 텍스트 노드만 추출 (너무 깊은 요소 제외 가능)
	    $('body').find('*').contents().filter(function () {
	      return this.nodeType === 3 && $.trim(this.nodeValue).length > 0;
	    }).each(function () {
	      nodeList.push(this);  // 번역 후 다시 쓰기 위함
	      originalTexts.push(this.nodeValue.trim());
	    });
	
	    $.ajax({
	      url: 'batchTranslate.do',
	      method: 'POST',
	      traditional: true, // List<String> 전송 필수
	      data: {
	        texts: originalTexts,
	        targetLang: targetLang
	      },
	      success: function (translatedTexts) {
	        for (let i = 0; i < nodeList.length; i++) {
	          nodeList[i].nodeValue = translatedTexts[i];
	        }
	      },
	      error: function () {
	        alert("전체 번역 중 오류가 발생했습니다.");
	      }
		});
	});
});