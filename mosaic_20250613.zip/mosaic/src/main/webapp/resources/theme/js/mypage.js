


//mypage tab
const tabButtons = document.querySelectorAll('.tab-btn');
const tabContents = document.querySelectorAll('.tab-content');
const profileButton = document.getElementById('profile-button');
const profileDropdown = document.getElementById('profile-dropdown');

const profileEditLink = document.getElementById('profile-edit-link');
const postsLink = document.getElementById('posts-link');
const commentsLink = document.getElementById('comments-link');
const privacyLink = document.getElementById('privacy-link');
const groupsLink = document.getElementById('groups-link');

let isDropdownOpen = false;


document.addEventListener('DOMContentLoaded', function() {
    const btn = document.getElementById('profile-button');
    const dropdown = document.getElementById('profile-dropdown');

    btn.addEventListener('click', function(e) {
      e.stopPropagation();
      dropdown.classList.toggle('hidden');
    });

    // 바깥 클릭 시 닫기
    document.addEventListener('click', function() {
      dropdown.classList.add('hidden');
    });

    // 드롭다운 내부 클릭 시 닫히지 않게
    dropdown.addEventListener('click', function(e) {
      e.stopPropagation();
    });
});

//mypage tab
const tabButtons = document.querySelectorAll('.tab-btn');
const tabContents = document.querySelectorAll('.tab-content');
const profileButton = document.getElementById('profile-button');
const profileDropdown = document.getElementById('profile-dropdown');

const profileEditLink = document.getElementById('profile-edit-link');
const postsLink = document.getElementById('posts-link');
const commentsLink = document.getElementById('comments-link');
const privacyLink = document.getElementById('privacy-link');
const groupsLink = document.getElementById('groups-link');

let isDropdownOpen = false;

function switchToTab(tabId, contentId) {
	tabButtons.forEach(btn => {
	btn.classList.remove('active-tab', 'bg-gray-100', 'text-primary');
	});

	const targetTab = document.getElementById(tabId);
	targetTab.classList.add('active-tab', 'bg-gray-100', 'text-primary');

	tabContents.forEach(content => {
	content.classList.remove('active');
	});

	document.getElementById(contentId).classList.add('active');
	profileDropdown.classList.add('hidden');
	isDropdownOpen = false;
	}

	function switchToProfileTab() {
	tabButtons.forEach(btn => {
	btn.classList.remove('active-tab', 'bg-gray-100', 'text-primary');
	});

	const profileTab = document.getElementById('profile-tab');
	profileTab.classList.add('active-tab', 'bg-gray-100', 'text-primary');

	tabContents.forEach(content => {
	content.classList.remove('active');
	});

	document.getElementById('profile-content').classList.add('active');
	profileDropdown.classList.add('hidden');
	isDropdownOpen = false;
	}

	function switchToPostsTab() {
	tabButtons.forEach(btn => {
	btn.classList.remove('active-tab', 'bg-gray-100', 'text-primary');
	});

	const postsTab = document.getElementById('posts-tab');
	postsTab.classList.add('active-tab', 'bg-gray-100', 'text-primary');

	tabContents.forEach(content => {
	content.classList.remove('active');
	});

	document.getElementById('posts-content').classList.add('active');
	profileDropdown.classList.add('hidden');
	isDropdownOpen = false;
	}

	function switchToCommentsTab() {
	tabButtons.forEach(btn => {
	btn.classList.remove('active-tab', 'bg-gray-100', 'text-primary');
	});

	const commentsTab = document.getElementById('comments-tab');
	commentsTab.classList.add('active-tab', 'bg-gray-100', 'text-primary');

	tabContents.forEach(content => {
	content.classList.remove('active');
	});

	document.getElementById('comments-content').classList.add('active');
	profileDropdown.classList.add('hidden');
	isDropdownOpen = false;
	}

	function switchToSettingsTab() {
	tabButtons.forEach(btn => {
	btn.classList.remove('active-tab', 'bg-gray-100', 'text-primary');
	});

	const settingsTab = document.getElementById('settings-tab');
	settingsTab.classList.add('active-tab', 'bg-gray-100', 'text-primary');

	tabContents.forEach(content => {
	content.classList.remove('active');
	});

	document.getElementById('settings-content').classList.add('active');
	profileDropdown.classList.add('hidden');
	isDropdownOpen = false;
	}

	function switchToGroupsTab() {
	tabButtons.forEach(btn => {
	btn.classList.remove('active-tab', 'bg-gray-100', 'text-primary');
	});

	const groupsTab = document.getElementById('groups-tab');
	groupsTab.classList.add('active-tab', 'bg-gray-100', 'text-primary');

	tabContents.forEach(content => {
	content.classList.remove('active');
	});

	document.getElementById('groups-content').classList.add('active');
	profileDropdown.classList.add('hidden');
	isDropdownOpen = false;
	}

profileEditLink.addEventListener('click', (e) => {
e.preventDefault();
switchToProfileTab();
});
postsLink.addEventListener('click', (e) => {
e.preventDefault();
switchToPostsTab();
});
commentsLink.addEventListener('click', (e) => {
e.preventDefault();
switchToCommentsTab();
});
privacyLink.addEventListener('click', (e) => {
e.preventDefault();
switchToSettingsTab();
});
groupsLink.addEventListener('click', (e) => {
e.preventDefault();
switchToGroupsTab();
});

profileButton.addEventListener('click', (e) => {
e.stopPropagation();
isDropdownOpen = !isDropdownOpen;
if (isDropdownOpen) {
profileDropdown.classList.remove('hidden');
} else {
profileDropdown.classList.add('hidden');
}
});
document.addEventListener('click', (e) => {
if (!profileDropdown.contains(e.target) && !profileButton.contains(e.target)) {
profileDropdown.classList.add('hidden');
isDropdownOpen = false;
}
});
tabButtons.forEach(button => {
button.addEventListener('click', () => {
// 모든 탭 버튼에서 active 클래스 제거
tabButtons.forEach(btn => {
btn.classList.remove('active-tab', 'bg-gray-100', 'text-primary');
});
// 클릭된 버튼에 active 클래스 추가
button.classList.add('active-tab', 'bg-gray-100', 'text-primary');
// 모든 탭 콘텐츠 숨기기
tabContents.forEach(content => {
content.classList.remove('active');
});
// 해당 탭 콘텐츠 표시
const tabId = button.id.replace('-tab', '-content');
document.getElementById(tabId).classList.add('active');
});
});
//});