// jQuery 존재 확인
if (typeof $ === 'undefined') {
    console.error("jQuery가 로드되지 않았습니다!");
    alert("jQuery가 로드되지 않았습니다!");
}

// 전역 변수
//let contextPath;

// 댓글 목록 로딩 함수 (전역)
function loadComments(page = 1) {
    console.log("loadComments 호출됨 - page:", page);
    console.log("contextPath:", contextPath);
    const postId = $('#comment_post_id').val();
    console.log("postId:", postId);

    if (!contextPath) {
        console.error("contextPath가 정의되지 않았습니다!");
        alert("contextPath가 정의되지 않았습니다!");
        return;
    }

    $.ajax({
      url: contextPath + "/comment/list",
      method: "GET",
      data: { 
          post_id: postId,
          page: page 
      },
      success: function (res) {
        console.log("댓글 목록 응답:", res);
        const list = res.comments;
        const totalPages = res.totalPages;

        // 댓글 리스트 렌더링 (JSP 스타일에 맞게)
        let html = '';
        if (list && list.length > 0) {
          list.forEach(c => {
            const formattedDate = formatDate(c.created_at);
            const userImg = c.user_img || '/mosaic/resources/theme/image/profile-default.png';
            
            html += `
              <div class="mt-8 space-y-6">
                <div class="border-b pb-4">
                  <div class="flex justify-between items-start">
                    <div class="flex items-start space-x-3">
                      <img src="${userImg}" alt="프로필" class="w-10 h-10 rounded-full border object-cover" />
                      <div class="space-y-1">
                        <div class="text-sm font-semibold text-gray-800">${escapeHtml(c.nickname)}</div>
                        <div class="text-xs text-gray-400">${formattedDate}</div>
                        <div class="text-sm text-gray-700">${escapeHtml(c.content)}</div>
                      </div>
                    </div>
                    <div class="flex space-x-2 text-right">
                      <button class="text-gray-400 hover:text-primary focus:outline-none edit-post-btn" onclick="editComment(${c.comment_id})">
                        <div class="w-5 h-5 flex items-center justify-center">
                          <i class="ri-edit-line"></i>
                        </div>
                      </button>
                      <button class="text-gray-400 hover:text-red-500 focus:outline-none" onclick="deleteComment(${c.comment_id})">
                        <div class="w-5 h-5 flex items-center justify-center">
                          <i class="ri-delete-bin-line"></i>
                        </div>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            `;
          });
        } else {
          html = '<div class="mt-8 text-center text-gray-500">아직 댓글이 없습니다.</div>';
        }
        
        $('#commentList').html(html);

        // 페이징 버튼 렌더링 (이벤트 위임 방식으로 변경)
        let pageHtml = '';
        for (let i = 1; i <= totalPages; i++) {
          const activeClass = (i === page) ? 'bg-primary text-white' : 'bg-white text-gray-700 hover:bg-gray-50';
          pageHtml += `<button class="page-btn px-3 py-1 border rounded ${activeClass}" data-page="${i}">${i}</button>`;
        }
        
        $('#commentPaging').html(pageHtml);
        console.log("댓글 목록 업데이트 완료 - 총 페이지:", totalPages, "현재 페이지:", page);
      },
      error: function(xhr, status, error) {
          console.error("댓글 로딩 실패:", error);
          console.error("응답:", xhr.responseText);
          console.error("상태:", xhr.status);
          $('#commentList').html('<div class="mt-8 text-center text-red-500">댓글을 불러오는데 실패했습니다.</div>');
      }
    });
}

// 날짜 포맷 YYYY-MM-DD HH:mm
function formatDate(datetime) {
    if (!datetime) return '';
    
    const date = new Date(datetime);
    
    // 유효한 날짜인지 확인
    if (isNaN(date.getTime())) {
        return datetime; // 원본 반환
    }
    
    return date.getFullYear() + '-' +
        ('0' + (date.getMonth() + 1)).slice(-2) + '-' +
        ('0' + date.getDate()).slice(-2) + ' ' +
        ('0' + date.getHours()).slice(-2) + ':' +
        ('0' + date.getMinutes()).slice(-2);
}

// HTML 이스케이프 처리
function escapeHtml(text) {
    return $('<div/>').text(text).html();
}

$(function () {
    console.log("reply.js DOM ready 실행됨");
    
    //contextPath = document.querySelector('meta[name="context-path"]').content;
    console.log("contextPath:", contextPath);

    // DOM 요소들 검증
    const replyForm = document.getElementById('replyForm');
    const replyConfirm = document.getElementById('replyConfirm');
    const commentPostId = document.getElementById('comment_post_id');
    const commentWriter = document.getElementById('comment_writer');
    const commentContent = document.getElementById('comment_content');
    
    console.log("replyForm:", replyForm);
    console.log("replyConfirm:", replyConfirm);
    console.log("commentPostId:", commentPostId ? commentPostId.value : null);
    console.log("commentWriter:", commentWriter ? commentWriter.value : null);
    console.log("commentContent:", commentContent);

    if (!replyForm) {
        console.error("replyForm 요소를 찾을 수 없습니다!");
        alert("replyForm 요소를 찾을 수 없습니다!");
        return;
    }
    
    if (!replyConfirm) {
        console.error("replyConfirm 버튼을 찾을 수 없습니다!");
        alert("replyConfirm 버튼을 찾을 수 없습니다!");
        return;
    }

    // 페이징 버튼 이벤트 위임
    $(document).on('click', '.page-btn', function() {
        const page = $(this).data('page');
        console.log("페이징 버튼 클릭됨 - page:", page);
        loadComments(page);
    });

    // 댓글 등록 - 폼 제출 이벤트
    $('#replyForm').submit(function (e) {
        e.preventDefault(); // 기본 submit 방지
        console.log("댓글 폼 제출됨");
        addComment();
    });

    // 댓글 등록 - 버튼 클릭 이벤트 (백업)
    $('#replyConfirm').on('click', function (e) {
        e.preventDefault(); // 기본 submit 방지
        console.log("댓글 버튼 클릭됨");
        addComment();
    });

    function addComment() {
        console.log("addComment 함수 실행됨");
        const postId = $('#comment_post_id').val();
        const userId = $('#comment_writer').val();
        const content = $('#comment_content').val();

        console.log("postId:", postId, "userId:", userId, "content:", content);

        if (!content.trim()) {
            alert("댓글 내용을 입력하세요.");
            return;
        }

        $.ajax({
            type: 'POST',
            url: contextPath + '/comment/add',
            data: {
                post_id: postId,
                user_id: userId,
                content: content
            },
            dataType: 'json',
            success: function (response) {
                console.log("댓글 등록 성공:", response);
                if (response.status === 'success') {
                    $('#comment_content').val(''); // 입력창 초기화
                    loadComments(1);               // 첫 번째 페이지로 새로고침
                    console.log("댓글이 등록되었습니다!");
                } else {
                    console.error(response.message || "댓글 등록에 실패했습니다.");
                }
            },
            error: function (xhr, status, error) {
                console.error("댓글 등록 오류:", error);
                console.error("응답:", xhr.responseText);
                alert("댓글 등록에 실패했습니다.");
            }
        });
    }

    loadComments(); // 초기 로딩 시 댓글 목록 출력
});