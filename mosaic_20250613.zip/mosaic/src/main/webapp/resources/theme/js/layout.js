//전역변수
const contextPath = document.querySelector('meta[name="context-path"]').content;

//로그인후 헤더 마이프로필 버튼
document.addEventListener('DOMContentLoaded', function() {	
	// 현재 페이지의 경로만 추출
	const path = window.location.pathname;
	console.log(path); // 예: /sample/page.html	
		
    const btn = document.getElementById('profile-button');
    const dropdown = document.getElementById('profile-dropdown');

    // 요소들이 존재하지 않으면 함수 종료
    if (!btn || !dropdown) {
      return;
    }

    btn.addEventListener('click', function(e) {  
    	e.stopPropagation();
    	dropdown.classList.toggle('hidden');  
    	if (window.location.pathname.includes("mypage")) {
	  
      }else{
      
      }
    });

    // 바깥 클릭 시 닫기
    document.addEventListener('click', function() {
      dropdown.classList.add('hidden');
    });

    // 드롭다운 내부 클릭 시 닫히지 않게
    dropdown.addEventListener('click', function(e) {
      e.stopPropagation();
    });
});

document.addEventListener('DOMContentLoaded', function () {
    const shareBtn = document.getElementById('shareButton');
    const sharePopup = document.querySelector('#sharePopup'); // popupShare.jsp 내 .modal-backdrop을 기준

    // shareBtn이 존재하지 않으면 함수 종료
    if (!shareBtn) {
      return;
    }

    shareBtn.addEventListener('click', function () {
    	console.log("공유하기 버튼 클릭");
      if (sharePopup) {
        //sharePopup.style.display = 'flex';
        sharePopup.classList.add('flex');
        sharePopup.classList.remove('hidden');
        document.body.classList.add('overflow-hidden');
      }
    });

    // 팝업 닫기 버튼
    document.querySelectorAll('#closeSharePopup').forEach(btn => {
      btn.addEventListener('click', function () {
        //sharePopup.style.display = 'none';
        sharePopup.classList.add('hidden');
        document.body.classList.remove('overflow-hidden');
      });
    });
});

document.addEventListener("DOMContentLoaded", function () {
      // const menuButton = document.querySelector(".md\\:hidden button");
      // if (menuButton) {
      //   menuButton.addEventListener("click", function () {
      //     console.log("Menu button clicked");
      //   });
      // }
      
      const languageButton = document.getElementById("languageButton");
      const languageDropdown = document.getElementById("languageDropdown");
      
      // 언어 버튼이 존재하지 않으면 함수 종료
      if (!languageButton || !languageDropdown) {
        return;
      }
      
      const languageButtons = languageDropdown.querySelectorAll(
        "button:not(:first-child)"
      );
      let currentLanguage = "한국어";
      
      function toggleDropdown() {
        const isVisible = !languageDropdown.classList.contains("hidden");
        if (isVisible) {
          languageDropdown.classList.add("hidden");
        } else {
          languageDropdown.classList.remove("hidden");
        }
      }
      
      function closeDropdown(event) {
        if (!document.getElementById("languageSelector").contains(event.target)) {
          languageDropdown.classList.add("hidden");
        }
      }
      
      languageButton.addEventListener("click", (e) => {
        e.stopPropagation();
        toggleDropdown();
      });
      
      document.addEventListener("click", closeDropdown)
      
      languageButtons.forEach((button) => {
        if (button.textContent.trim() === currentLanguage) {
          button.setAttribute("data-active", "true");
        }
        button.addEventListener("click", () => {
          languageButtons.forEach((btn) =>
            btn.setAttribute("data-active", "false")
          );
          button.setAttribute("data-active", "true");
          currentLanguage = button.textContent.trim();
          console.log(`Selected language: ${currentLanguage}`);
          languageDropdown.classList.add("hidden");
        });
      });
});
  
      
  //카테고리 태그  
  document.addEventListener("DOMContentLoaded", function () {
    const categoryTags = document.getElementById("categoryTags");
    const allTag = document.getElementById("tagAll");
    const expandButton = document.getElementById("expandButton");
    
    // 요소들이 존재하지 않으면 함수 종료
    if (!categoryTags || !expandButton) {
      return;
    }
    
    const hiddenTags = Array.from(
      document.querySelectorAll("#categoryTags .tag.hidden")
    );
    let activeTags = new Set(["all"]);
    let isExpanded = false;
    
    expandButton.addEventListener("click", function () {
      isExpanded = !isExpanded;
      hiddenTags.forEach((tag) => {
        tag.classList.toggle("hidden");
      });
      this.textContent = isExpanded ? "Collapse" : "Expand";
    });
    
    function updateTagStyles() {
      const tags = categoryTags.querySelectorAll(".tag");
      tags.forEach((tag) => {
        const isActive = activeTags.has(tag.id.toLowerCase().replace("tag", ""));
        tag.classList.remove(
          "bg-gray-100",
          "bg-primary",
          "text-gray-800",
          "text-white"
        );
        if (isActive) {
          tag.classList.add("bg-primary", "text-white");
          tag.querySelector("span").classList.remove("text-gray-500");
          tag.querySelector("span").classList.add("text-white/80");
        } else {
          tag.classList.add("bg-gray-100", "text-gray-800");
          tag.querySelector("span").classList.remove("text-white/80");
          tag.querySelector("span").classList.add("text-gray-500");
        }
      });
    }
    
    categoryTags.addEventListener("click", function (e) {
      const tagButton = e.target.closest(".tag");
      if (!tagButton) return;
      const tagId = tagButton.id.toLowerCase().replace("tag", "");
      if (tagId === "all") {
        if (activeTags.has("all")) {
          activeTags.delete("all");
        } else {
          activeTags.clear();
          activeTags.add("all");
        }
      } else {
        activeTags.delete("all");
        if (activeTags.has(tagId)) {
          activeTags.delete(tagId);
          if (activeTags.size === 0) {
            activeTags.add("all");
          }
        } else {
          activeTags.add(tagId);
        }
      }
      updateTagStyles();
    });
  });      