const initialData = {
  name: 'StoryMosaic',
  location: 'Earth',
  about: [
    {
      insert: '당신의 이야기를 들려주세요.',
    },
  ],
};

// 글자수 체크
class Counter {
  constructor(quill, options) {
    const container = document.querySelector(options.container);
    quill.on(Quill.events.TEXT_CHANGE, () => {
      const text = quill.getText();
      if (options.unit === 'word') {
        container.innerText = text.trim().split(/\s+/).length + ' words';
      } else {
        container.innerText = text.length + ' characters';
      }
    });
  }
}
Quill.register('modules/counter', Counter);

// ✅ 이미지 업로드 핸들러
const imageHandler = () => {
  const input = document.createElement('input');
  input.setAttribute('type', 'file');
  input.setAttribute('accept', 'image/*');
  input.click();
  input.onchange = async () => {
    const file = input.files[0];
    if (file) {
      const MAX_SIZE = 5 * 1024 * 1024;

      if (file.size > MAX_SIZE) {
        alert("이미지 파일은 5MB 이하만 업로드할 수 있습니다.");
        return;
      }

      const formData = new FormData();
      formData.append('image', file);

      try {
        const res = await fetch('/mosaic/resources/upload/story', {
          method: 'POST',
          body: formData
        });
        const result = await res.json();

        if (result.url) {
          const range = quill.getSelection();
          quill.insertEmbed(range.index, 'image', result.url);
        } else {
          alert(result.error || '이미지 업로드 실패');
        }
      } catch (err) {
        console.error('Image upload failed:', err);
        alert('이미지 업로드 중 오류 발생');
      }
    }
  };
};

// ✅ 커스텀 핸들러 함수들
const customHandlers = {
  translate: () => {
    const range = quill.getSelection();
    if (range) {
      const selectedText = quill.getText(range.index, range.length);
      if (selectedText.trim()) {
        // TODO: DeepL API 연동 또는 테스트용 알림
        alert("번역 결과: (예시) " + selectedText + " → TranslatedText");
        // quill.insertText(range.index + range.length, " → TranslatedText");
      } else {
        alert("번역할 텍스트를 선택하세요.");
      }
    }
  },
  map: () => { 
  	//console.log("웹에디터에서 지도 버튼 클릭"); 
  	document.querySelector('#btnPopupMap').click();	
  
    const range = quill.getSelection();
    /*const mapEmbed = `<iframe src="https://maps.google.com/maps?q=Seoul&t=&z=13&ie=UTF8&iwloc=&output=embed" 
                      width="100%" height="300" frameborder="0"></iframe>`;
    quill.clipboard.dangerouslyPasteHTML(range.index, mapEmbed);
    */
  },
  calendar: () => {
  	document.querySelector('#btnPopupSchedule').click();	
    /*
    const range = quill.getSelection();
    const dateInput = prompt("일정을 입력하세요 (예: 2025-06-01 14:00 회의)");
    if (dateInput) {
      quill.insertText(range.index, `📅 ${dateInput}`);
    }
    */
  }
};


const options = {
  debug: 'info',
  modules: {
    counter: {
      container: '#counter',
      unit: 'word'
    },
    imageResize: {
      displaySize: true
    },
    toolbar: {  
      container: [
        [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
        ['bold', 'italic', 'underline', 'strike'],
        [{ 'color': [] }, { 'background': [] }],
        [{ 'align': [] }],
        ['link', 'blockquote'],
        [{ list: 'ordered' }, { list: 'bullet' }],
        ['code-block', 'image'],

        // ✅ 커스텀 버튼들
        ['translate', 'map', 'calendar']
        
      ],
      handlers: {
        image: imageHandler,
        translate: customHandlers.translate,
        map: customHandlers.map,
        calendar: customHandlers.calendar        
      }
    },
  },
  theme: 'snow',
  placeholder: '내용을 입력해 주세요.',
};

const quill = new Quill('#editor-content', options);

// 초기값 세팅
const resetForm = () => {
  // 수정 페이지에서는 기존 내용이 있으면 그것을 사용
  if (typeof existingContent !== 'undefined' && existingContent) {
    quill.root.innerHTML = existingContent;
  } else {
    // 새 글 작성시에만 기본값 사용
    if (document.querySelector('[name="name"]')) {
      document.querySelector('[name="name"]').value = initialData.name;
    }
    if (document.querySelector('[name="location"]')) {
      document.querySelector('[name="location"]').value = initialData.location;
    }
    quill.setContents(initialData.about);
  }
};
resetForm();

// 폼 제출 시 Quill 데이터 포함
const form = document.querySelector('form');
form.addEventListener('formdata', (event) => {
  event.formData.append('about', JSON.stringify(quill.getContents().ops));
});

// 리셋 버튼
document.querySelector('#resetForm').addEventListener('click', () => {
  resetForm();
});
