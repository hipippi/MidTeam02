$(function () {
    //const contextPath = document.querySelector('meta[name="context-path"]').content;
    
    // 언어 코드 → 표시용 언어 이름 맵
    const langMap = {
        EN: '영어',
        JA: '일본어',
        ZH: '중국어',
        KO: '한국어'
    };

    /**
     * 번역 수행 함수
     * @param {string} originSelector 원본 콘텐츠 셀렉터 (예: '#editor-content .ql-editor')
     * @param {string} targetSelector 번역결과 출력 셀렉터 (예: '#translated-content')
     * @param {string} lang 코드 (예: 'EN')
     * @param {string|null} hiddenInputSelector 숨김필드 셀렉터 (optional)
     * @param {string|null} langNameSelector 언어명 표시 셀렉터 (optional)
     */
    function translateHtmlText(originSelector, targetSelector, lang, hiddenInputSelector = null, langNameSelector = null) {
        const originContent = $(originSelector);
        const targetContent = $(targetSelector);
        const originHtml = originContent.html();

        if (lang === 'KO') {
            targetContent.html(originHtml);
            if (langNameSelector) {
                $(langNameSelector).text(langMap[lang] || lang);
            }
            return;
        }

        $.ajax({
            url: contextPath + '/translateText.do',
            method: 'POST',
            data: {
                text: originHtml,
                targetLang: lang
            },
            dataType: "text",
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            success: function (result) {
            	console.log("번역된 텍스트: ", result); 
            	
                //targetContent.html(result);
                targetContent.html('');             // 먼저 비우고
				targetContent.append($.parseHTML(result)); // HTML로 파싱하여 삽입
                //targetContent.innerHTML = result;
                targetContent.removeClass("bg-gray-100");

                if (hiddenInputSelector) {
                    $(hiddenInputSelector).val(result);
                }
                if (langNameSelector) {
                    $(langNameSelector).text(langMap[lang] || lang);
                }
            },
            error: function () {
                console.log('번역 중 오류 발생');
            }
        });
    }

    // ----------------------------
    // 쓰기 화면: 번역 언어 선택
    // ----------------------------
    $('#language_target').change(function () {
        const lang = $(this).val();
        translateHtmlText(
            '#editor-content',    // 원본
            '#content-translated',           // 번역결과
            lang,
            '#content-hidden',               // 숨김 필드 (form 제출용)
            '#language-target-name'          // 언어 표시
        );
    });

    // ----------------------------
    // 보기 화면: 번역 언어 선택
    // ----------------------------
    const viewOriginHtml = $('#postContent').html();  // 최초 로딩 시 원본 저장

    $('#lang-btn').change(function () {
        const lang = $(this).val();

        if (lang === 'KO') {
            $('#postContentTranslated').html(viewOriginHtml);
            return;
        }

        translateHtmlText(
            '#postContent',              // 원본
            '#postContentTranslated',    // 번역된 결과 출력
            lang
        );
    });
});
