// 팝업 열기/닫기
const btnPopupMap = document.getElementById('btnPopupMap');
const popupMap = document.getElementById('popupMap');
const btnCloseMap = document.getElementById('btnCloseMap');
let modalBackdrop = null; 

btnPopupMap.addEventListener("click", function (e) {
	e.preventDefault();
	openPopup();
	setTimeout(() => map.relayout(), 100); // 팝업 열릴 때 지도 리사이즈	  
});
btnCloseMap.addEventListener("click", function (e) { 
 e.preventDefault();
  closePopup();  
});

function openPopup(){
  if (!modalBackdrop) {
	// backdrop 동적 생성
	modalBackdrop = document.createElement('div');
	modalBackdrop.className = 'modal-backdrop fixed inset-0 flex items-center justify-center z-50';
	document.body.appendChild(modalBackdrop);
	popupMap.style.display = 'block';   
	modalBackdrop.appendChild(popupMap);
	document.body.classList.add('overflow-hidden'); 	
  }
}
function closePopup() {
  popupMap.style.display = 'none';

  if (modalBackdrop) {
    document.body.removeChild(modalBackdrop);
    modalBackdrop = null;
    document.body.classList.remove('overflow-hidden'); 
  }
}

// 지도 및 장소 검색
var mapContainer = document.getElementById('map'),
    mapOption = {
      center: new kakao.maps.LatLng(37.566826, 126.9786567),
      level: 3
    };
var map = new kakao.maps.Map(mapContainer, mapOption);
var ps = new kakao.maps.services.Places();
var markers = [];
var infowindow = new kakao.maps.InfoWindow({zIndex:1});

// 장소 검색
const btnSearchPlace = document.getElementById('btnSearchPlace');
 btnSearchPlace.addEventListener("click", function (e) { 	
	e.preventDefault();
      e.stopPropagation();
      selectPlace();
 });
//selectPlace
function selectPlace(){
	var keyword = document.getElementById('keyword').value.trim();
   
  if (!keyword) {
    alert('검색어를 입력하세요!');
    return;
  }
  ps.keywordSearch(keyword, placesSearchCB);
}

// 검색 결과 콜백
function placesSearchCB(data, status, pagination) {
  var placesList = document.getElementById('placesList');
  placesList.innerHTML = '';
  if (status === kakao.maps.services.Status.OK) {
    // 기존 마커 삭제
    markers.forEach(function(m) { m.setMap(null); });
    markers = [];
    var bounds = new kakao.maps.LatLngBounds();
    data.forEach(function(place, idx) {
      // 리스트에 표시
      var li = document.createElement('li');
      li.textContent = place.place_name + ' (' + place.address_name + ')';
      placesList.appendChild(li);

      // 지도에 마커 표시
      var position = new kakao.maps.LatLng(place.y, place.x);
      var marker = new kakao.maps.Marker({ map: map, position: position });
      markers.push(marker);
      bounds.extend(position);

      // 리스트 클릭/마커 클릭 이벤트 동일하게 처리
      function selectPlace() {
        infowindow.setContent('<div style="padding:5px;font-size:14px;">' + place.place_name + '</div>');
        infowindow.open(map, marker);
        // 미리보기 지도 및 정보 표시
        showSelectedMap(place.y, place.x, place.place_name, place.address_name, place.place_id);
        
        // hidden input에 값 저장
        // place 객체의 주요 필드: place_name, x(경도), y(위도), address_name(지번주소), road_address_name(도로명주소)
	    //document.getElementById('location_id').value = place.place_id;
	    
	    
	    document.getElementById('place_name').value = place.place_name;
	    document.getElementById('latitude').value = place.y;
	    document.getElementById('longitude').value = place.x;
	    document.getElementById('address').value = place.address_name || place.road_address_name || '';
        
        // 커스텀 이벤트 발생 (storyEdit.jsp에서 사용)
        $(document).trigger('mapLocationSelected', {
          place_name: place.place_name,
          latitude: place.y,
          longitude: place.x,
          address: place.address_name || place.road_address_name || ''
        });
        
        // 팝업 닫기
        //popupMap.style.display = 'none';
        closePopup();
      }
      li.addEventListener('click', selectPlace);
      kakao.maps.event.addListener(marker, 'click', selectPlace);
    });
    map.setBounds(bounds);
  } else {
    placesList.innerHTML = '<li>검색 결과가 없습니다.</li>';
  }
}

// 미리보기 지도 표시
function showSelectedMap(lat, lng, name, address) {
  document.getElementById('mapWidget').style.display = 'block';
  
  var mapDiv = document.getElementById('selectedMap');
  var infoDiv = document.getElementById('selectedInfo');
  mapDiv.style.display = 'block';
  infoDiv.innerHTML = '<b>선택된 장소:</b> ' + name + '<br><small>' + address + '</small>';
  var selectedMap = new kakao.maps.Map(mapDiv, {
    center: new kakao.maps.LatLng(lat, lng),
    level: 3
  });
  var marker = new kakao.maps.Marker({
    position: new kakao.maps.LatLng(lat, lng),
    map: selectedMap
  });
  var infowindow = new kakao.maps.InfoWindow({
    content: '<div style="padding:5px;font-size:14px;">' + name + '</div>'
  });
  infowindow.open(selectedMap, marker);
}		   