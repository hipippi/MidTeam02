//스토리 뷰
document.addEventListener("DOMContentLoaded", function () {
    const tabOriginal = document.getElementById("tab-original");
    const tabTranslated = document.getElementById("tab-translated");
    const contentOriginal = document.getElementById("tab-content-original");
    const contentTranslated = document.getElementById("tab-content-translated");

    tabOriginal.addEventListener("click", function () {
      tabOriginal.classList.add("active-tab");
      tabTranslated.classList.remove("active-tab");
      contentOriginal.classList.remove("hidden");
      contentTranslated.classList.add("hidden");
    });

    tabTranslated.addEventListener("click", function () {
      tabOriginal.classList.remove("active-tab");
      tabTranslated.classList.add("active-tab");
      contentOriginal.classList.add("hidden");
      contentTranslated.classList.remove("hidden");
    });
  });

 //스토리 글쓰기 
 // HTML에서 text 200자 추출 (JSoup 말고 그냥 DOM으로도 가능하지만, 여기선 Quill 기준)
	function extractSummary() {
	  // Quill 에디터의 실제 HTML을 가져옴
	  const tempDiv = document.createElement('div');
	  tempDiv.innerHTML = document.querySelector('#editor-content .ql-editor').innerHTML;
	  
	  const text = tempDiv.innerText.replace(/\s+/g, ' ').trim();
	  return text.substring(0, 200); // 최대 200자
	}
	
	function extractThumbUrl() {
	  const tempDiv = document.createElement('div');
	  tempDiv.innerHTML = document.querySelector('#editor-content .ql-editor').innerHTML;
	  
	  // 이미지 모두 가져온 후 첫 번째 것만 사용
	  const imgs = tempDiv.querySelectorAll('img');
	  const firstImg = imgs.length > 0 ? imgs[0].getAttribute('src') : '';
	
	  console.log("첫 번째 이미지 src:", firstImg);
	
	  return firstImg;
	}

	 
  	document.getElementById("storyForm").addEventListener("submit", function (e) {
	  const editor = document.getElementById("editor-content");
	  const contentHidden = document.getElementById("content-hidden");
	  const contentTranslated = document.getElementById("content-translated");
	  const contentTranslatedHidden = document.getElementById("content-translated-hidden");
	
	  if (editor.innerHTML.trim() === "") {
	    e.preventDefault();
	    document.getElementById("contentError").classList.remove("hidden");
	    return;
	  }
	
	  contentHidden.value = editor.innerHTML;
	  contentTranslatedHidden.value = contentTranslated.innerHTML;
	
	  const summary = extractSummary();
	  const thumbUrl = extractThumbUrl();
	
	  document.querySelector('#summary').value = summary;
	  document.querySelector('#thumb_url').value = thumbUrl;
	
	  console.log("요약:", summary);
	  console.log("썸네일 URL:", thumbUrl);
	});




