$(function(){
	$('#showMoreBtn').on('click', function() {
    const $desc = $('.description-text');
    $desc.toggleClass('expanded');
    $(this).text($desc.hasClass('expanded') ? '접기' : '더보기');
  });

	const partStatus = $('#part_status').val();
	if (partStatus === 'host') {
	$('.host-buttons').removeClass('hidden');
	} else if (partStatus === 'participant') {
	$('.participant-buttons').removeClass('hidden');
	} else {
    $('.non-participant-buttons').removeClass('hidden');
	}	
	console.log("AJAX 호출 준비됨");
	
	// 댓글목록 가져오기
	function groupPartList(){
		$.ajax({
			type:'get'
			, url:'groupPartList'
            , data: {
                group_id: $('#group_id').val(),
                user_id: $('#user_id').val()
            }
			, dataType:'json'
			, success: function(result){
				
				var partList = $('#partList');
				partList.empty();
				
			    var loginUserStatus = result.loginUserStatus;
			    var list = result.partList; // 여기에서 실제 배열을 추출
				
				for( row of list ){
					//console.log(row);
					var tr = $('<tr/>');
					
			        tr.append($('<td/>').html(row['part_id']));
			        tr.append($('<td/>').html(row['nickname']));
			        tr.append($('<td/>').html(row['part_status']));
					
					// 수정버튼과 삭제버튼 추가
				    if (loginUserStatus === 'host' && row['part_status']!== 'host') {
				        tr.append('<td><button class="delete">삭제</button></td>');
				    } else {
				        tr.append('<td></td>'); // 또는 아무것도 안 추가해도 됨
				    }
					
					partList.append(tr);
					
				}
				
			}
			,error: function(err){
				alert('검색실패');
				console.log(err);
			}
			
		}); // end of ajax
	}

	$('#btn-modal').click(function(){
		groupPartList();
	if (partStatus !== 'host') {
	$('.delete').css({
		display : 'none'
	});
	}	

	});


	// 동적 '삭제'버튼 이벤트 클릭시
	$('#partList').on('click', '.delete', function(){
		
		var part_id = $(this).parents('tr').children().eq(0).text();
		//alert(rno);
		
		$.ajax({
			type:'delete'
			, url:'deleteGroupPart/'+ part_id
			, success:function(result){
				alert(result);
				partList.remove(tr)
				partList();
			}
			, error:function(err){
				alert('삭제실패');
				console.log(err);
			}			
		});
		
	});
	
  // 카드 호버 효과
  $('.card').hover(
    function() {
      $(this).addClass('shadow-md');
    },
    function() {
      $(this).removeClass('shadow-md');
    }
  );

  // 태그 삭제
  $('.tag button').on('click', function() {
    $(this).closest('.tag').remove();
  });


});

