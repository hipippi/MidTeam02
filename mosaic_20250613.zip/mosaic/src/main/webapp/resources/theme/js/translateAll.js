function applyTranslatedTexts(textNodes, translatedArray) {
    for (let i = 0; i < textNodes.length; i++) {
        textNodes[i].node.nodeValue = translatedArray[i] || "";
    }
}

function handleTranslationFlow() {
	    const editableDiv = document.getElementById("originalTextDiv");
	    const clonedDiv = editableDiv.cloneNode(true); // 원본 보존
	    const textNodes = extractTextNodes(clonedDiv);

	    const textsToTranslate = textNodes.map(item => item.text);

	    if (textsToTranslate.length === 0) return;

	    $.ajax({
	        url: "/translate",
	        method: "POST",
	        contentType: "application/json",
	        data: JSON.stringify({
	            texts: textsToTranslate,
	            sourceLang: $("#sourceLang").val(),
	            targetLang: $("#targetLang").val()
	        }),
	        success: function (res) {
	            // res.translatedTexts: ["안녕", "세계!"]
	            applyTranslatedTexts(textNodes, res.translatedTexts);
	            const translatedHTML = clonedDiv.innerHTML;
	            $("#translatedTextDiv").html(translatedHTML);
	            $("#translatedContentHidden").val(translatedHTML);
	        },
	        error: function () {
	            $("#translatedTextDiv").text("번역 실패"); ///상세에서 오류
	        }
	    });
	}
   
   let debounceTimer = null;
   $("#originalTextDiv").on("input", function () {
       clearTimeout(debounceTimer);
       debounceTimer = setTimeout(() => {
           handleTranslationFlow();
       }, 700);
   });