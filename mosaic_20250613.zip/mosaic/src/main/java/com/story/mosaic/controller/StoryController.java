package com.story.mosaic.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.story.mosaic.model.CommentVO;
import com.story.mosaic.model.LocationVO;
import com.story.mosaic.model.PageVO;
import com.story.mosaic.model.ScheduleVO;
import com.story.mosaic.model.StoryVO;
import com.story.mosaic.service.CommentService;
import com.story.mosaic.service.StoryService;

@Controller	
@RequestMapping("/story")
public class StoryController {
	
	@Autowired	
	private StoryService storyService;
	
	@Autowired
	private CommentService commentService;
	
	//단순 view파일 연결만 하는 함수. 네이밍 규칙으로	
	//@RequestMapping("/{step}.do")
	@RequestMapping("/{step}.do")			//step 변수명 아래 매핑된게 없으면 step실행
	public String viewpage(@PathVariable String step){	//step이라는 변수는 경로변수	
		System.out.println("step:"+step);
		return "story/"+step;
	}
	
	@RequestMapping("/view") 				
	public String selectStory(StoryVO vo, LocationVO lo, ScheduleVO so, Model model) {
		if (vo.getPost_id() == null) {
			return "redirect:/story/list";
		}
		
		try {
			storyService.selectStoryView(vo, lo, so, model);
			return "story/storyView";
		} catch (RuntimeException e) {
			return "redirect:/story/list";
		}
	}
	
	
	// 수정 폼 진입
	@GetMapping("/edit")
	public String editStory(StoryVO vo, LocationVO lo, ScheduleVO so, Model model) {
	    if (vo.getPost_id() == null) {
			return "redirect:/story/list";
		}
		try {
			storyService.selectStoryView(vo, lo, so, model);
			return "story/storyEdit";
		} catch (RuntimeException e) {
			return "redirect:/story/list";
		}
	}

	// 실제 수정 처리
	@RequestMapping("/update")
	public String updateStory(StoryVO vo, LocationVO lo, ScheduleVO so) {
	    storyService.updateStory(vo, lo, so);
	    return "redirect:/story/view?post_id=" + vo.getPost_id();
	}

	// 삭제
	@RequestMapping("/delete")
	public String deleteStory(StoryVO vo, LocationVO lo, ScheduleVO so) {
	    storyService.deleteStory(vo, lo, so);
	    return "redirect:/story/list";
	}
	
	
	@RequestMapping("/write")
	public String insertStory(StoryVO vo) {		
		System.out.println("Controller /write insertStory vo.toString() :"+ vo.toString());
		return "story/storyWrite";
	}	

	@GetMapping("/listByCategories")
	public String getStoriesByCategories(@RequestParam(name="categories") List<String> categories, Model model) {
		if (categories != null) {
	        categories = categories.stream()
	            .map(String::trim)
	            .filter(s -> !s.isEmpty())
	            .collect(Collectors.toList());
	    }
	    List<StoryVO> storyList;
	    if (categories == null || categories.isEmpty()) {
	        storyList = storyService.getStoryList(new HashMap<>());
	    } else {
	        storyList = storyService.getStoriesByCategories(categories);
	    }
	    model.addAttribute("storyList", storyList);
	    return "story/storyListFragment";
	}
	
	@RequestMapping("/list")
	public String getStoryList(Model m,
	                           @RequestParam(defaultValue = "1") int page,
	                           @RequestParam(defaultValue = "10") int size,
	                           @RequestParam(required = false) String searchCondition,
	                           @RequestParam(required = false) String searchKeyword) {

	    Map<String, Object> map = new HashMap<>();
	    map.put("searchCondition", searchCondition);
	    map.put("searchKeyword", searchKeyword);

	    // 페이징 계산
	    PageVO pageVO = new PageVO();
	    pageVO.setPage(page);
	    pageVO.setSize(size);
	    int totalCount = storyService.getStoryCount(map);
	    pageVO.setTotalCount(totalCount);
	    pageVO.calculate();

	    map.put("startRow", pageVO.getStartRow());
	    map.put("endRow", pageVO.getEndRow());

	    List<StoryVO> storyList = storyService.getPagedStoryList(map);
	    for (StoryVO story : storyList) {
	        if (story.getTags() != null) {
	            story.setTagList(Arrays.asList(story.getTags().split("\\s*,\\s*")));
	        }
	    }

	    m.addAttribute("storyList", storyList);
	    m.addAttribute("pageVO", pageVO);
	    m.addAttribute("searchCondition", searchCondition);
	    m.addAttribute("searchKeyword", searchKeyword);
	    m.addAttribute("size", size);

	    return "story/storyMain";
	}

		
	// @RequestMapping("updateStory.do")
	// public String updateStory(StoryVO vo, LocationVO lo, ScheduleVO so, Model model) {			
	// 	storyService.updateStory(vo, lo, so);	
	// 	return "redirect:getStory.do?seq="+vo.getPost_id();	
	// }
	
	@RequestMapping("deleteStory.do")
	public String deleteStory(StoryVO vo, LocationVO lo, ScheduleVO so, Model model) {	
		storyService.deleteStory(vo, lo, so);	
		return "redirect:getStoryList.do";	
	}
	
	@RequestMapping("/saveStory.do")
	public String saveStory(StoryVO vo, LocationVO lo, ScheduleVO so, Model model) {	
	    // ★ JSoup 처리로 summary, thumbnail 설정은 Service 내부에서 수행   
	    storyService.insertStory(vo, lo, so);  	   
		// 등록 후 리스트로 리다이렉트
		return "redirect:/story/list";
	}
}
