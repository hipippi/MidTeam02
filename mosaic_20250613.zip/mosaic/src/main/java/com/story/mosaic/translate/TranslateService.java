package com.story.mosaic.translate;

public interface TranslateService {
    String translate(String text, String targetLang);
}