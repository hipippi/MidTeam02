package com.story.mosaic.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.story.mosaic.model.AdminLoginVO;
import com.story.mosaic.model.NoticeVO;
import com.story.mosaic.service.NoticeService;

@Controller
@RequestMapping("/admin")
public class AdminNoticeController {
	
	@Autowired
	private NoticeService noticeservice;
	
	@GetMapping("/noticeTest")
	public String noticeList(@RequestParam(required = false) String keyword,
	                         @RequestParam(required = false, defaultValue = "ALL") String type,
	                         Model model) {

	    List<NoticeVO> noticeList = noticeservice.searchNotices(keyword, type);
	    model.addAttribute("noticeList", noticeList);
	    model.addAttribute("keyword", keyword);
	    model.addAttribute("type", type);
	    model.addAttribute("currentPage", "notice"); // 사이드바용 현재 탭 설정

	    return "admin/noticeTest";
	}
	//공지사항 등록 화면 
	@GetMapping("/noticeInsert")
	public String showInsertForm() {
		return "admin/noticeInsert";
	}
	//공지사항 등록 처리 
	@PostMapping("/noticeInsert")
	public String insertNotice(@ModelAttribute NoticeVO vo, HttpSession session) {
		// 세션에서 로그인된 관리자 정보 가져오기
		AdminLoginVO loginAdmin = (AdminLoginVO) session.getAttribute("adminLogin");

		// admin_id 세팅 (중요!)
		vo.setAdmin_id(loginAdmin.getAdmin_id());

		// 저장 처리
		noticeservice.insertNotice(vo);
		return "redirect:/admin/noticeTest";
	}

	// 공지사항 상세 보기 + 조회수 증가 처리 포함
	@GetMapping("/noticeDetail")
	public String noticeDetail(@RequestParam("notice_id") int notice_id, Model model) {

	    // 조회수 증가
	    noticeservice.increaseViews(notice_id);

	    // 해당 공지사항 데이터 조회
	    NoticeVO notice = noticeservice.getNoticeById(notice_id);

	    // 데이터를 model에 담음
	    model.addAttribute("notice", notice);

	    // 상세보기 페이지로 이동
	    return "admin/noticeDetail";
	}
	//수정 페이지 
	@GetMapping("/noticeUpdate")
	public String showUpdateForm(@RequestParam("notice_id") int notice_id,Model model) {
		//해당 공지 ID로 DB에서 기존 데이터 조회
		NoticeVO notice = noticeservice.getNoticeById(notice_id);
		model.addAttribute("notice", notice);
		return "admin/noticeUpdate";
	}
	//수정 처리
	@PostMapping("/noticeUpdate")
	public String UpdateNotice(@ModelAttribute NoticeVO vo) {
		//폼에서 전송된 name 값들을 → VO 객체에 자동으로 담아줌
		noticeservice.updateNotice(vo); //입력받은값으로 db수정
		return "redirect:/admin/noticeTest";
	}
	//삭제 처리
	@GetMapping("/noticeDelete")
	public String deleteNotice(@RequestParam("notice_id")int notice_id) {
		// 해당 ID의 공지사항을 삭제
		noticeservice.deleteNotice(notice_id);
		// 삭제 후 목록페이지로 이동
		return "redirect:/admin/noticeTest";
	}
	// 공지사항 등록 (Ajax 처리용)
	@PostMapping("/noticeInsertAjax")
	@ResponseBody
	public Map<String, Object> insertNoticeAjax(@RequestBody NoticeVO vo, HttpSession session) {
	    Map<String, Object> response = new HashMap<>();

	    try {
	        // 세션에서 로그인 관리자 정보 가져오기
	        AdminLoginVO loginAdmin = (AdminLoginVO) session.getAttribute("adminLogin");
	        vo.setAdmin_id(loginAdmin.getAdmin_id()); // admin_id 세팅

	        noticeservice.insertNotice(vo); // DB 저장
	        response.put("result", "success");
	    } catch (Exception e) {
	        response.put("result", "fail");
	        response.put("error", e.getMessage());
	    }

	    return response;
	}





}
	