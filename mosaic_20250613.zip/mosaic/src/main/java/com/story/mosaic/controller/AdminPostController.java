package com.story.mosaic.controller;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.story.mosaic.model.AdminPostVO;
import com.story.mosaic.service.AdminPostService;

@Controller
@RequestMapping("/admin")
public class AdminPostController {

    @Autowired
    private AdminPostService adminPostService;

 // 게시물 관리 화면 진입 시 전체 게시물 리스트를 조회하여 전달
    @GetMapping("/postManage")
    public String postManage(@RequestParam(defaultValue = "story") String type, Model model) {
    	// 요청 파라미터로 받은 type(story/group)에 따라 게시물 목록 조회
        List<AdminPostVO> postList = adminPostService.getPostByType(type);
        
        // 조회된 목록과 선택된 탭 타입을 JSP로 전달
        model.addAttribute("postList", postList);
        model.addAttribute("selectedType", type); // 탭 강조용
        return "admin/AdminPostManage";
    }
    @PostMapping("/deletePost")
    public String deletePost(@RequestParam("postId") int postId,
                             @RequestParam("type") String type) {
        if ("group".equals(type)) {
            // 모임 게시물 삭제
            adminPostService.deleteGroupPost(postId);
        } else {
            // story 게시물 삭제
            adminPostService.deletePost(postId, type);
        }
      //삭제후 새로고침 원래있던 기존페이지
         return "redirect:/admin/postManage?type=" + type;
    }
   // 게시물 공개 상태(공개 / 비공개) 변경 처리
    @PostMapping("/updateStatus")
    @ResponseBody
    public String updateStatus(@RequestParam("postId") int postId,
    						   @RequestParam("type") String type,
    						   @RequestParam("status") String status) {
    	
    	// Service 호출하여 상태값 업데이트 처리
    	adminPostService.updateStatus(postId, type, status);
    	return "ok";
    }
    
}
