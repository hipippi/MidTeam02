package com.story.mosaic.model;
import java.sql.Timestamp;
import lombok.Data;

@Data
public class ScheduleVO {
	private Integer		schedule_id;				// 스케줄 ID (Primary Key)
	private String		schedule_title;	
	private Boolean		schedule_important;	
	private String		memo;	
	private Integer		post_id;	
    private String 		start_datetime;				// 원래 String 타입 날짜 입력 (폼에서 받음)
    private String 		end_datetime;
    
    private Timestamp 	start_datetime_timestamp;	// DB 저장용 Timestamp 타입 필드 (매퍼에 연결)
    private Timestamp 	end_datetime_timestamp;    
}