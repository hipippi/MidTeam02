package com.story.mosaic.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.story.mosaic.model.VisitorLogVO;
import com.story.mosaic.repo.VisitorLogDAO;

// Spring이 이 클래스를 서비스 컴포넌트로 등록하게 해주는 어노테이션
@Service
public class VisitorLogServiceImpl implements VisitorLogService{
	// DAO를 자동으로 연결 (빈 주입)
	@Autowired 
	private VisitorLogDAO visitorLogDAO;

	@Override
	public void insertVisitorLog(VisitorLogVO vo) {
		// DAO 메서드를 호출해서 visitor_log 테이블에 저장함
		visitorLogDAO.insertVisitorLog(vo);
	}

	@Override
	public List<VisitorLogVO> getVisitorStatsByWeek(String month) {

		return visitorLogDAO.getVisitorStatsByWeek(month);
	}

	
}
