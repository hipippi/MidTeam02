package com.story.mosaic.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.story.mosaic.model.AdminGroupVO;
import com.story.mosaic.service.AdminGroupService;

@Controller
@RequestMapping("/admin")
public class AdminGroupController {

	@Autowired
	private AdminGroupService adminGroupService;
	
	//모임 상세정보 ajax용
    @GetMapping("/getGroupDetail")
    @ResponseBody  // JSON 형태로 응답
    public AdminGroupVO getGroupDetail(@RequestParam("group_id") int group_id) {
    	
        System.out.println("[모임상세] 조회할 ID: " + group_id);
        
        AdminGroupVO detail = adminGroupService.getGroupDetail(group_id);
        
        System.out.println("[모임상세] 조회결과: " + detail);
        return detail;
    }

}
