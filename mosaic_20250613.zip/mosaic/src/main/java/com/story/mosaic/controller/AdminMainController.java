package com.story.mosaic.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.story.mosaic.model.NoticeVO;
import com.story.mosaic.service.AdminPostService;
import com.story.mosaic.service.AdminReportService;
import com.story.mosaic.service.AdminUserService;
import com.story.mosaic.service.NoticeService;

@Controller
public class AdminMainController {
	
	@Autowired
	private AdminReportService reportService;
	
	@Autowired
	private NoticeService noticeService;
	
	@Autowired
	private AdminPostService adminPostService;
	
	@Autowired
	private AdminUserService adminUserserivce;

	@GetMapping("/admin/adminMain")
	public String adminMain(Model model) {
		
	//신고글 수 조회해서 model에 저장
	int reportCount = reportService.getReportCount();
	model.addAttribute("reportCount", reportCount);
	
	

	// 공지사항 목록을 조회 (NoticeService → DAO → DB)
	List<NoticeVO> recentNotices = noticeService.getRecentNotices();
	
	model.addAttribute("recentNotices", recentNotices);
	// 현재 페이지 정보 (사이드 메뉴 하이라이트용)
    model.addAttribute("currentPage", "dashboard");
	// 스토리마당 게시물수 조회
    int storyPostCount = adminPostService.getStoryPostCount();
    
    model.addAttribute("storyPostCount", storyPostCount);
    
    // 모임 게시물수 조회
    int groupPostCount = adminPostService.getGroupPostCount();
    model.addAttribute("groupPostCount", groupPostCount);
    
	// 사용자 통계 데이터
	int totalUserCount = adminUserserivce.getTotalUserCount();
	int recentUserCount = adminUserserivce.getRecentUserCount();
	int suspendedUserCount = adminUserserivce.getSuspendedUserCount();

	model.addAttribute("totalUserCount", totalUserCount);
	model.addAttribute("recentUserCount", recentUserCount);
	model.addAttribute("suspendedUserCount", suspendedUserCount);
    //admin 에 값 리턴
	return "admin/adminMain";
	}
    // ajax를 이용한 국가별 회원수 통계차트
    @GetMapping("/admin/nationalityStats")
    @ResponseBody
    public List<Map<String, Object>> getNationalityChart(){
    	
    	return adminUserserivce.getNationalityChart();
    }
	
}
