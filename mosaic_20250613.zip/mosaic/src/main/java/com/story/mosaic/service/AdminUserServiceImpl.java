package com.story.mosaic.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.story.mosaic.model.AdminUserVO;
import com.story.mosaic.repo.AdminUserDAO;

@Service
public class AdminUserServiceImpl implements AdminUserService {

    @Autowired
    private AdminUserDAO adminUserDAO;

    // 회원 리스트 조회
    @Override
    public List<AdminUserVO> getUserList() {
        return adminUserDAO.getUserList();
    }

    // 회원 상태 업데이트 (정지 / 활성)
    @Override
    public int updateStatus(AdminUserVO vo) {
        return adminUserDAO.updateStatus(vo);
    }

    // 회원 정지 시: 해당 유저의 모든 게시물/모임글 비공개 처리
    @Override
    public void hideUserContent(String user_id) {
        adminUserDAO.hideUserStoryPosts(user_id);
        adminUserDAO.hideUserGroupPosts(user_id);
    }

    // 회원 활성 시: 해당 유저의 모든 게시물/모임글 공개 처리
    @Override
    public void showUserContent(String user_id) {
        adminUserDAO.showUserStoryPosts(user_id);
        adminUserDAO.showUserGroupPosts(user_id);
    }

    // 국가별 회원수 통계차트
	@Override
	public List<Map<String, Object>> getNationalityChart() {
		
		return adminUserDAO.getNationalityChart();
	}

	// 전체 회원 수 조회
	@Override
	public int getTotalUserCount() {
		
		return adminUserDAO.getTotalUserCount();
	}
	// 최근 가입 회원 수 조회
	@Override
	public int getRecentUserCount() {
		
		return adminUserDAO.getRecentUserCount();
	}
	// 정지된 회원 수 조회
	@Override
	public int getSuspendedUserCount() {
		
		return adminUserDAO.getSuspendedUserCount();
	}
    
}
