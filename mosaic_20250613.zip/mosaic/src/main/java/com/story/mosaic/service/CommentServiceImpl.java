package com.story.mosaic.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.story.mosaic.model.CommentVO;
import com.story.mosaic.repo.CommentDAO;

@Service("commentService")
public class CommentServiceImpl implements CommentService {

    @Autowired
    private CommentDAO commentDAO;

    @Override
    public void insertComment(CommentVO vo) {
        commentDAO.insertComment(vo);
    }
    
    @Override
    public void updateComment(CommentVO vo) {
        commentDAO.updateComment(vo);
    }
    
    @Override
    public void deleteComment(CommentVO vo) {
        commentDAO.deleteComment(vo);
    }
    
    @Override
    public List<CommentVO> getCommentsByPostId(Integer post_id) {
        return commentDAO.getCommentsByPostId(post_id);
    }

    @Override
    public List<CommentVO> getCommentsByPostIdPaged(Integer post_id, int page, int pageSize) {
        int offset = (page - 1) * pageSize;
        Map<String, Object> params = new HashMap<>();
        params.put("postId", post_id);
        params.put("offset", offset);
        params.put("limit", pageSize);
        return commentDAO.getCommentsByPostIdPaged(params);
    }

    @Override
    public int countCommentsByPostId(Integer post_id) {
        return commentDAO.countCommentsByPostId(post_id);
    }
    
    @Override
    public void deleteCommentsByPostId(Integer post_id) {
        commentDAO.deleteCommentsByPostId(post_id);
    }
}