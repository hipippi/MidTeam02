package com.story.mosaic.model;

import java.util.Date;

import lombok.Data;

@Data
public class AdminManagerVO {

    private int admin_id;           // 관리자 고유 ID (PK)
    private String admin_name;      // 관리자 이름
    private String admin_email;     // 관리자 이메일 (로그인 ID)
    private String admin_password;  // 로그인 비밀번호
    private String admin_level;     // 관리자 권한 (예: 일반, 최고)
    private Date created_at;        // 등록일자
}
