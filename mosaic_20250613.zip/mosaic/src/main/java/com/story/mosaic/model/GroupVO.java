package com.story.mosaic.model;


import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class GroupVO {
	private Integer group_id;
	private String group_title;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date group_date;
	private String group_content;
	private String user_id;
	private String group_image; //파일명
	private String group_irealname; //저장된 파일이름
	private long group_isize; //파일크기
	private String nickname;
	
	private MultipartFile file;
	
}
