package com.story.mosaic.repo;

import org.apache.ibatis.annotations.Mapper;

import com.story.mosaic.model.ScheduleVO;

@Mapper	
public interface ScheduleDAO {
    ScheduleVO selectSchedule(ScheduleVO so);
	void insertSchedule(ScheduleVO so);
    void updateSchedule(ScheduleVO so);
    void deleteSchedule(ScheduleVO so);
}