package com.story.mosaic.model;

import lombok.Data;

@Data
public class AdminUserVO {
    private String user_id;      // 회원 ID
    private String name;         // 이름
    private String nickname;     // 닉네임
    private String email;        // 이메일
    private String password;     // 비밀번호
    private String nationality;  // 국적
    private String city;         // 지역
    private String sns_id;       // SNS 연동 ID
    private String user_img;     // 프로필 이미지
    private String join_date;    // 가입일자
    private String status;       // 상태 ('활성' 또는 '정지')
}

