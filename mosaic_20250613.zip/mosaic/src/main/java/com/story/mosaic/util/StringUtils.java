package com.story.mosaic.util;

public class StringUtils {

    // HTML 태그 제거
    public static String stripHtmlTags(String html) {
        if (html == null) return "";
        return html.replaceAll("<[^>]*>", "").replaceAll("&nbsp;", " ").trim();
    }

    // HTML 제거 후 50자만 자르기
    public static String getSummary(String html, int maxLength) {
        String plainText = stripHtmlTags(html);
        return plainText.length() > maxLength ? plainText.substring(0, maxLength) + "..." : plainText;
    }
}
