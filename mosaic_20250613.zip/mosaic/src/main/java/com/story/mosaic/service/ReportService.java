package com.story.mosaic.service;

import java.util.List;

import com.story.mosaic.model.ReportVO;

public interface ReportService {
	//신고 목록 조회 
	public List<ReportVO> getReportList();

	//신고 처리 
	public int updateReportStatus(ReportVO vo);
}
