package com.story.mosaic.repo;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.story.mosaic.model.SnsVO;

@Mapper
public interface SnsDAO {

    int insert(SnsVO snsVO);

    SnsVO get(@Param("sns_id") String snsId, @Param("sns_platform") String platform);

    SnsVO getByUserId(@Param("user_id") String user_id);

    int delete(SnsVO snsVO);
    
    // SNS ID와 플랫폼으로 사용자 조회
//    SnsVO findBySnsIdAndPlatform(@Param("sns_id") String sns_id,
//            @Param("sns_platform") String sns_platform);
    
        void saveRandomId(String kakaoId, String nickname, String randomId);


}
