package com.story.mosaic.model;

import lombok.Data;

@Data
public class LocationVO {
    private Integer 	location_id;	
    private	Integer		post_id;              
    private String		address_detail; 	
    private String		address;  			//지도api필수 db : name, lat, lng, address	
    private String  	place_name;			//장소이름	name
    private Double  	latitude; 			//위도 	lat
    private Double	 	longitude; 			//경도	long
    private String 		place_id;			//장소 id(카카오 관리)    
}