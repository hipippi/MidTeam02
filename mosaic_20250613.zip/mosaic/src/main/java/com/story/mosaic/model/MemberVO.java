package com.story.mosaic.model;

import lombok.Data;

@Data
public class MemberVO {
    private String user_id;      // 회원 No
    private String email;         // 이메일 (회원 ID)
    private String password;      // 비밀번호
    private String nickname;      // 닉네임
    private String nationality;   // 국적    
    private String province;     // 도
    private String city;         // 시
    private String join_date;    // 가입일자
    private String sns_id;       // SNS ID
    private String name;         // 이름
    private String user_img;     // 회원사진
    private String language;
    private String status;
    
} 
