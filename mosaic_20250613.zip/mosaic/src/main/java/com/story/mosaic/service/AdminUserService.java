package com.story.mosaic.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.story.mosaic.model.AdminUserVO;
import com.story.mosaic.repo.AdminUserDAO;

@Service
public interface AdminUserService {
	//회원 목록 조회
	List<AdminUserVO> getUserList();
	
	//회원 상태 업데이트 (활성,정지)
	public int updateStatus(AdminUserVO vo);
	
	//정지된 유저의 게시물/모임글을 비공개처리
	public void hideUserContent(String user_id);
	
    // 활성화된 유저의 스토리 게시물/모임글을 공개처리
    public void showUserContent(String user_id);
    
    // 국가별 회원수 통계차트 
    public List<Map<String, Object>> getNationalityChart();
	
    // 전체 회원 수 조회
    public int getTotalUserCount();

    // 최근 가입 회원 수 조회 (월 기준)
    public int getRecentUserCount();

    // 정지된 회원 수 조회
    public int getSuspendedUserCount();
}
