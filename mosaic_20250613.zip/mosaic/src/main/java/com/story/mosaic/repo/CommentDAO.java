package com.story.mosaic.repo;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.story.mosaic.model.CommentVO;

@Mapper
public interface CommentDAO {
    CommentVO selectLocation(CommentVO co);
    void insertComment(CommentVO co);
    void updateComment(CommentVO co);     
    void deleteComment(CommentVO co);  

    List<CommentVO> getCommentsByPostId(Integer post_id);
    List<CommentVO> getCommentsByPostIdPaged(Map<String, Object> params);
    int countCommentsByPostId(Integer post_id);
	public void deleteCommentsByPostId(Integer post_id);
}