package com.story.mosaic.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.story.mosaic.model.AdminUserVO;
import com.story.mosaic.service.AdminUserService;

@Controller
@RequestMapping("/admin")
public class AdminUserController {

	@Autowired
	private AdminUserService adminUserService;
    @GetMapping("/userList")
    public String userList(Model model) {
    	
    	List<AdminUserVO> list = adminUserService.getUserList();
    	
    	model.addAttribute("userList", list);
    	model.addAttribute("currentPage", "user"); //탭 강조
    	return "admin/AdminUserList";
    }
    //ajax
    @PostMapping("/updateUserStatus")
    @ResponseBody
    public String updateUserStatus(@RequestBody AdminUserVO vo) {
        int result = adminUserService.updateStatus(vo);
        
        // 상태가 '정지'로 변경된 경우에만 게시물 비공개 처리
        if ("정지".equals(vo.getStatus())) {
            adminUserService.hideUserContent(vo.getUser_id());
        }else if ("활성".equals(vo.getStatus())){	
        	adminUserService.showUserContent(vo.getUser_id());
        }
        return result == 1 ? "success" : "fail";
    } 
    
}
