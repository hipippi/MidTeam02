package com.story.mosaic.service;

import com.story.mosaic.model.MemberVO;
import com.story.mosaic.model.SnsVO;

public interface SnsService {
	
	   void saveRandomId(String kakaoId, String nickname, String randomId);

//    
//    // SNS 연동 정보 저장
//    void saveSnsLink(SnsVO snsVO);
//
//    // userId 기준으로 연동 정보 조회
//    SnsVO findByUserId(String user_id);
//    
//    // snsId + 플랫폼으로 SNS 연동된 사용자 조회 (카카오 로그인 시 사용됨)
//    SnsVO findBySnsIdAndPlatform(String snsId, String platform);
//
//    // SNS 연동 해제
//    void deleteSnsLink(String user_id, String platform);
//    
//    // SNS 회원 등록 및 중복검사
//    MemberVO registerSnsUser(SnsVO snsVO);
}
