package com.story.mosaic.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.story.mosaic.service.MemberService;

@Controller
@RequestMapping("/api")
public class SnsController {

	
	
    private final String clientId = "2ba93ad381f76536f8047c648555f818"; // 카카오 REST API 키 입력
    private final String redirectUri = "http://localhost:8080/mosaic/kakao/callback";

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();

//    private final SnsService snsService;
    private final MemberService memberService;

    @Autowired
    public SnsController(MemberService memberService) {
//    public SnsController(SnsService snsService, MemberService memberService) {
//        this.snsService = snsService;
        this.memberService = memberService;
    }


    // 카카오 로그인 버튼 클릭 시 카카오 인증 페이지로 리다이렉트
    @RequestMapping("/kakao/login")
    public String kakaoLogin() throws UnsupportedEncodingException {
        String encodedRedirectUri = URLEncoder.encode(redirectUri, "UTF-8");
        String kakaoAuthUrl = "https://kauth.kakao.com/oauth/authorize"
                + "?client_id=" + clientId
                + "&redirect_uri=" + encodedRedirectUri
                + "&response_type=code";
        System.out.println("서버를 거치냐");
        return "redirect:" + kakaoAuthUrl;
    }

    // 카카오 로그인 콜백 처리
    @GetMapping("/kakao/callback")
    public String kakaoCallback(
            @RequestParam("code") String code,
            @RequestParam(value = "state", required = false) String state,
            HttpSession session,
            HttpServletResponse response,
            Model model) {
        try {
            // 1. 액세스 토큰 요청
            String tokenUrl = "https://kauth.kakao.com/oauth/token";
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

            MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
            params.add("grant_type", "authorization_code");
            params.add("client_id", clientId);
            params.add("redirect_uri", redirectUri);
            params.add("code", code);

            HttpEntity<MultiValueMap<String, String>> tokenRequest = new HttpEntity<>(params, headers);
            ResponseEntity<String> tokenResponse = restTemplate.exchange(tokenUrl, HttpMethod.POST, tokenRequest, String.class);

            String accessToken = objectMapper.readTree(tokenResponse.getBody()).get("access_token").asText();

            // 2. 사용자 정보 요청
            HttpHeaders infoHeaders = new HttpHeaders();
            infoHeaders.set("Authorization", "Bearer " + accessToken);
            HttpEntity<Void> infoRequest = new HttpEntity<>(infoHeaders);

            ResponseEntity<String> userInfoResponse = restTemplate.exchange(
                "https://kapi.kakao.com/v2/user/me", HttpMethod.GET, infoRequest, String.class
            );

            JsonNode userInfo = objectMapper.readTree(userInfoResponse.getBody());
            String snsId = userInfo.path("id").asText();
            String nickname = userInfo.path("properties").path("nickname").asText();

            // 카카오 계정 정보에서 이메일 확인, 없으면 임시 이메일 생성
            JsonNode kakaoAccount = userInfo.path("kakao_account");
            String email = "";
            if (kakaoAccount.has("email") && !kakaoAccount.get("email").isNull() && !kakaoAccount.get("email").asText().isEmpty()) {
                email = kakaoAccount.path("email").asText();
            } else {
                email = "kakao_" + snsId + "@temp.com";  // 임시 이메일
            }

            // 3. SNS 회원 조회 및 가입 처리
//            SnsVO snsUser = snsService.findBySnsIdAndPlatform(snsId, "kakao");
//
//            if (snsUser == null) {
//                // 신규 회원 가입
//                String userId = memberService.registerSnsUser(email, nickname, snsId);
//                snsUser = new SnsVO();
//                snsUser.setSns_id(snsId);
//                snsUser.setUser_id(userId);
//                snsUser.setSns_platform("kakao");
//                snsService.saveSnsLink(snsUser);
//            }

            

            
         // 4. 세션에 로그인 정보 저장
            session.setAttribute("sns_id", snsId);        // 카카오에서 받은 고유 ID
            session.setAttribute("nickname", nickname);   // 카카오 닉네임
            session.setAttribute("email", email);         // 카카오 이메일

            // 5. 로그인 유지(자동 로그인) 체크 시 sns_id를 쿠키에 저장
            if ("rememberLogin".equals(state)) {
                Cookie cookie = new Cookie("rememberLogin", snsId);
                cookie.setMaxAge(60 * 60 * 24 * 14); // 2주
                cookie.setHttpOnly(true);
                cookie.setPath("/");
                response.addCookie(cookie);
            }


            // 6. 로그인 성공 페이지로 이동
            model.addAttribute("nickname", nickname);
            model.addAttribute("email", email);

            return "loginConfirm";

        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("error", "카카오 로그인 실패: " + e.getMessage());
            return "error";
        }
    }

    // 자동 로그인 처리 예시 (매 요청마다 세션이 없을 때 쿠키 검사)
    // 이 메서드는 필터나 인터셉터로 구현하는 것이 일반적이지만,
    // 예시로 컨트롤러에 추가
}