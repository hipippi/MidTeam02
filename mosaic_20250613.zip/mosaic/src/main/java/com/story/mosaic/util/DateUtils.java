package com.story.mosaic.util;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.ParseException;

public class DateUtils {
    public static Timestamp stringToTimestamp(String dateStr) throws ParseException {
        // 입력받는 문자열 형식에 맞게 패턴 지정 (예: "2025-05-29 14:30")
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        
        // 문자열 → Date 변환
        Date parsedDate = sdf.parse(dateStr);
        
        // Date → Timestamp 변환
        return new Timestamp(parsedDate.getTime());
    }
    
    // 테스트용 메인 메서드
    public static void main(String[] args) {
        String dateStr = "2025-05-29 14:30";
        try {
            Timestamp ts = stringToTimestamp(dateStr);
            System.out.println(ts);  // 출력 예: 2025-05-29 14:30:00.0
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
}
