package com.story.mosaic.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.story.mosaic.model.AdminLoginVO;
import com.story.mosaic.repo.AdminLoginDAO;

@Service
public class AdminLoginServiceImpl implements AdminLoginService {

	@Autowired
	private AdminLoginDAO adminLoginDAO;
	
	@Autowired
	private PasswordEncoder passwordEncoder;

	@Override
	public AdminLoginVO login(String email, String rawPassword) {
	    AdminLoginVO dbAdmin = adminLoginDAO.findByEmail(email);

	    //console 값 체크 
	    System.out.println("[로그인 입력] email: " + email);
	    System.out.println("[로그인 입력] password(입력): " + rawPassword);
	    System.out.println("[로그인 DB] password(DB): " + dbAdmin.getAdmin_password());
	    System.out.println("[로그인 비교 결과]: " + passwordEncoder.matches(rawPassword, dbAdmin.getAdmin_password()));
	    
	    if (dbAdmin != null && passwordEncoder.matches(rawPassword, dbAdmin.getAdmin_password())) {
	        return dbAdmin;
	    }
 
	    return null;
	}
	
}
