package com.story.mosaic.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class VisitorLogVO {
	
	private Integer visit_id;
	private String visit_date;
	private String user_ip;
	private String page;
	private String user_agent;
	private String session_id;

	private String week_label;  // 예: "1주차", "2주차" 등
	private int visit_count;    // 각 주차별 방문자 수
}
