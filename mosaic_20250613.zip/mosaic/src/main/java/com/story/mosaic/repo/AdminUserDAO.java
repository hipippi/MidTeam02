package com.story.mosaic.repo;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.story.mosaic.model.AdminUserVO;

@Mapper
public interface AdminUserDAO {
	//회원 목록 조회
	List<AdminUserVO> getUserList();
	
	//회원 상태 업데이트 (활성,정지)
	public int updateStatus(AdminUserVO vo);
	
    //  유저의 스토리 게시물 상태를 변경
    public void hideUserStoryPosts(String user_id);

    // 유저의 모임 게시물 상태를 변경
    public void hideUserGroupPosts(String user_id);
    
    // 유저의 스토리 게시물 상태를 변경
    public void showUserStoryPosts(String user_id);
    
    //유저의 모임 게시물 상태를 변경
    public void showUserGroupPosts(String user_id);
    
    //국가별 회원수 그래프
    public List<Map<String, Object>> getNationalityChart();
    
    //  전체 회원 수
    public int getTotalUserCount();

    //  최근 가입한 회원 수
    public int getRecentUserCount();

    //  정지된 회원 수
    public int getSuspendedUserCount();
}
