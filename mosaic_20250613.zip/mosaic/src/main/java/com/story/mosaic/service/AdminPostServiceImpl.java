package com.story.mosaic.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.story.mosaic.model.AdminPostVO;
import com.story.mosaic.repo.AdminPostDAO;

@Service
public class AdminPostServiceImpl implements AdminPostService {
	
	@Autowired
	private AdminPostDAO adminpostDAO;
	// 특정 타입(story/group)의 게시물만 가져오기
	@Override
	public List<AdminPostVO> getPostByType(String type) {
		
		return adminpostDAO.getPostsByType(type);
	}
	// 게시물 상태(정상/비공개) 업데이트
	@Override
	public void updateStatus(int postId, String type, String status) {
		 // DAO에게 게시물 ID, 타입(story/group), 변경 상태를 넘겨 DB 업데이트 수행
		adminpostDAO.updateStatus(postId, type, status);
		
	}
	// 게시물 삭제 처리
	@Override
	public void deletePost(int postId, String type) {
		// postId와 게시물 타입(story/group)을 기반으로 DAO에게 삭제를 지시
		adminpostDAO.deletePost(postId, type);
		
	}
	//스토리마당 게시물수 조회
	@Override
	public int getStoryPostCount() {
		
		return adminpostDAO.getStoryPostCount();
	}
	//모임 게시물수 조회
	@Override
	public int getGroupPostCount() {
		
		return adminpostDAO.getGroupPostCount();
	}
	//모임 파트 삭제
	@Override
	public void deleteGroupPost(int groupId) {
		adminpostDAO.deleteGroupPart(groupId);
		adminpostDAO.deleteGroup(groupId);
	}

}
