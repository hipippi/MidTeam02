package com.story.mosaic.repo;

import java.util.Map;
import org.apache.ibatis.annotations.Mapper;
import com.story.mosaic.model.MemberVO;

@Mapper
public interface MemberDAO {
	//이메일로 회원 조회
	MemberVO findByEmail(String email);

	//로그인용 회원 조회
	MemberVO getMember(MemberVO vo);

    // 회원가입
    void insertMember(MemberVO vo);

    // 이메일 중복체크
    int emailCheck(String email);

    // 닉네임 중복체크
    int nicknameCheck(String nickname);

    // 비밀번호 업데이트
    int updatePassword(Map<String, String> params);

    MemberVO findByUserId(String userId);

}
