package com.story.mosaic.service;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Arrays;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;

import com.story.mosaic.model.LocationVO;
import com.story.mosaic.model.ScheduleVO;
import com.story.mosaic.model.StoryVO;
import com.story.mosaic.model.CommentVO;
import com.story.mosaic.repo.LocationDAO;
import com.story.mosaic.repo.ScheduleDAO;
import com.story.mosaic.repo.StoryDAO;
import com.story.mosaic.repo.CommentDAO;

@Service("storyService")	                     
public class StoryServiceImpl implements StoryService {		
	@Autowired
	private StoryDAO storyDAO;
	
	@Autowired
	private LocationDAO locationDAO;
	
	@Autowired
	private ScheduleDAO scheduleDAO;
	
	@Autowired
	private CommentDAO commentDAO;

    @Override
    @Transactional
    public void selectStoryView(StoryVO vo, LocationVO lo, ScheduleVO so, Model model) {
        Integer post_id = vo.getPost_id();
        
        // 1. 게시글 조회 및 조회수 증가
        StoryVO story = storyDAO.selectStory(vo);
        if (story == null) {
            throw new RuntimeException("Story not found");
        }
        storyDAO.increaseViewCount(story);
        model.addAttribute("story", story);

        // 2. 위치 정보 조회
        lo.setPost_id(post_id);
        LocationVO location = locationDAO.selectLocation(lo);
        if (location != null) {
            model.addAttribute("location", location);
        }

        // 3. 일정 정보 조회
        so.setPost_id(post_id);
        ScheduleVO schedule = scheduleDAO.selectSchedule(so);
        if (schedule != null) {
            model.addAttribute("schedule", schedule);
        }
        
        // 4. 댓글 목록 조회
        List<CommentVO> comments = commentDAO.getCommentsByPostId(post_id);
        if (comments == null) {
            comments = new ArrayList<>();
        }
        model.addAttribute("comments", comments);
        
        // 5. 태그 처리
        if (story.getTags() != null && !story.getTags().trim().isEmpty()) {
            List<String> tagList = Arrays.asList(story.getTags().split("\\s*,\\s*"));
            if (!tagList.isEmpty()) {
                model.addAttribute("tagList", tagList);
            }
        }
    }

    @Override
    public List<String> getCategoryList() {
        return storyDAO.getCategoryList();
    }
    
    @Override
    public List<StoryVO> getStoriesByCategories(List<String> categories) {
        return storyDAO.getStoriesByCategories(categories);
    }
    
    @Override
    public List<StoryVO> getStoryList(HashMap map) {
        return storyDAO.getStoryList(map);
    }
    
    @Override
    public int getStoryCount(Map<String, Object> map) {
        return storyDAO.getStoryCount(map);
    }
    
    @Override
    public List<StoryVO> getPagedStoryList(Map<String, Object> map) {
        return storyDAO.getPagedStoryList(map);
    }

    @Override
    public void increaseViewCount(StoryVO vo) {
        storyDAO.increaseViewCount(vo);
    }

    @Override
    @Transactional
    public void updateStory(StoryVO vo, LocationVO lo, ScheduleVO so) {
    	Integer post_id = vo.getPost_id();
    	
        // 1. 게시글 수정
        storyDAO.updateStory(vo);
        
        // 2. 위치 정보 수정
        if (lo != null && lo.getLatitude() != null && lo.getLongitude() != null) {
            lo.setPost_id(post_id);
            locationDAO.updateLocation(lo);
        }

        // 3. 일정 정보 수정
        if (so != null && so.getStart_datetime() != null && so.getEnd_datetime() != null) {
            setScheduleTimestamp(so);
            so.setPost_id(post_id);
            scheduleDAO.updateSchedule(so);
        }
    }

    //일정 날짜 변환 
    private void setScheduleTimestamp(ScheduleVO so) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            if (so.getStart_datetime() != null && !so.getStart_datetime().isEmpty()) {
                Date startDate = sdf.parse(so.getStart_datetime());
                so.setStart_datetime_timestamp(new Timestamp(startDate.getTime()));
            }
            if (so.getEnd_datetime() != null && !so.getEnd_datetime().isEmpty()) {
                Date endDate = sdf.parse(so.getEnd_datetime());
                so.setEnd_datetime_timestamp(new Timestamp(endDate.getTime()));
            }
        } catch (ParseException e) {
            e.printStackTrace();
            throw new RuntimeException("날짜 파싱 오류 발생: " + e.getMessage());
        }
    }

    //통합 등록 (게시글 + 위치 + 일정)
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void insertStory(StoryVO vo, LocationVO lo, ScheduleVO so) {
        System.out.println("=== insertStory 디버깅 ===");
        System.out.println("StoryVO: " + vo);
        System.out.println("LocationVO: " + lo);
        System.out.println("ScheduleVO: " + so);
        
        // 1. 게시글 저장
        storyDAO.insertStory(vo);
        Integer post_id = vo.getPost_id();
        System.out.println("등록된 post_id: " + post_id);
        
        // 2. 위치 정보 있을 경우만 저장
        if (lo != null && 
            lo.getLatitude() != null && lo.getLongitude() != null &&
            lo.getPlace_name() != null && !lo.getPlace_name().trim().isEmpty()) {
            
            System.out.println("위치 정보 등록: " + lo);
            lo.setPost_id(post_id);
            locationDAO.insertLocation(lo);
        } else {
            System.out.println("위치 정보 없음 - 스킵");
        }

        // 3. 일정 정보 있을 때만 등록
        if (so != null &&
            so.getSchedule_title() != null && !so.getSchedule_title().trim().isEmpty() &&
            so.getStart_datetime() != null && !so.getStart_datetime().trim().isEmpty() &&
            so.getEnd_datetime() != null && !so.getEnd_datetime().trim().isEmpty()) {
            
            System.out.println("일정 정보 등록: " + so);
            setScheduleTimestamp(so);
            so.setPost_id(post_id);
            scheduleDAO.insertSchedule(so);
        } else {
            System.out.println("일정 정보 없음 - 스킵");
        }
        
        System.out.println("=== insertStory 완료 ===");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteStory(StoryVO vo, LocationVO lo, ScheduleVO so) {
        if (vo == null || vo.getPost_id() == null) {
            throw new IllegalArgumentException("유효하지 않은 게시글 정보입니다.");
        }
        
        Integer post_id = vo.getPost_id();

        // 1. 댓글 먼저 삭제
        commentDAO.deleteCommentsByPostId(post_id);

        // 2. 위치, 일정 등도 있다면 삭제
        LocationVO locationToDelete = new LocationVO();
        locationToDelete.setPost_id(post_id);
        locationDAO.deleteLocation(locationToDelete);
        
        ScheduleVO scheduleToDelete = new ScheduleVO();
        scheduleToDelete.setPost_id(post_id);
        scheduleDAO.deleteSchedule(scheduleToDelete);

        // 3. 게시글 본문 삭제
        storyDAO.deleteStory(vo);
    }


}