package com.story.mosaic.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.story.mosaic.model.MemberVO;
import com.story.mosaic.repo.MemberDAO;
import com.story.mosaic.service.MemberService;
import com.story.mosaic.service.MemberServiceImpl;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class MemberController {

    private final MemberService memberService;
    private final MemberDAO memberDAO;

    private final javax.servlet.ServletContext servletContext;
    
    // 마이페이지 페이지 이동 
    @GetMapping("/mypage")
    public String mypage() {
        return "member/mypage"; // mypage.jsp
    }
    
    // 로그인 페이지 이동 (/login)
    @GetMapping("/login")
    public String loginForm() {
        return "member/login"; // login.jsp
    }

    @PostMapping("/login")
    public String login(MemberVO vo,	//사용자가 입력한 이메일, 비밀번호가 담긴 곳
                        @RequestParam(value = "rememberLogin", required = false, defaultValue = "false") boolean rememberLogin, 	//아이디 기억하기 체크박스, 체크했으면 true, 안했으면 false. 
                        HttpSession session, 	//로그인 정보 잠깐 기억해두는 상자. 이것을 통해 로그인한 상태인지 아닌지 구별 가능
                        HttpServletResponse response,	//사용자 컴퓨터로 쿠키를 보내주는 도구
                        RedirectAttributes redirectAttributes,  // 다른 화면으로 넘어갈 때, 메시지를 함께 들고 가는 쪽지 같은 역할
                        Model model) {	//현재 화면에 사용자에게 보여줄 정보가 담김

        System.out.println("=== 컨트롤러 로그인 시도 ===");
        System.out.println("전달받은 이메일: " + vo.getEmail());
        System.out.println("전달받은 비밀번호: " + vo.getPassword());

        MemberVO loginMember = memberService.login(vo);

        if (loginMember != null) {
            System.out.println("[로그인 성공] 이메일: " + loginMember.getEmail());
            session.setAttribute("loginMember", loginMember);	//로그인한 사람 정보를 서버에 저장해둠, 사이트를 돌아다닐 때마다 로그인 상태 유지 가능
            session.setAttribute("user_id", loginMember.getUser_id());  // user_id도 세션에 저장
            System.out.println(loginMember.getUser_id());
            System.out.println(loginMember.getNickname());
            
            // 성공 메시지 추가
            redirectAttributes.addFlashAttribute("msg", "로그인 되었습니다.");		//로그인 성공 메시지를 쪽지로 저장
            
            //아이디 기억하기 처리 (쿠키 설정)
            if (rememberLogin) {
                Cookie cookie = new Cookie("rememberId", loginMember.getEmail());
                cookie.setMaxAge(700 * 24 * 60 * 60); // 7일간 유지
                cookie.setPath("/");
                response.addCookie(cookie);
            } else {
                Cookie cookie = new Cookie("rememberId", null);
                cookie.setMaxAge(0); // 쿠키 삭제
                cookie.setPath("/");
                response.addCookie(cookie);
            }
            return "redirect:/"; 	//메인페이지로
        } else {
            System.out.println("[로그인 실패] 이메일: " + vo.getEmail());
            model.addAttribute("error", "이메일 또는 비밀번호가 일치하지 않습니다.");
            return "member/login";
        }
    }

    // ★★★★★★관리자 로그인 -> 관리자 로그인 경로로 수정
    @GetMapping("/loginConfirm") 
    public String loginConfirm() {
        return "member/loginConfirm"; 
    }

    
    //스토리 메인 화면으로 이동
//    @RequestMapping("story/storyMain")
//    public String storyMainPage() {
//        // 메인 페이지로 이동하는 로직
//        return "story/storyMain";  // storyMain.jsp 또는 storyMain.html 등을 반환
//    }
    
    
    //회원가입 버튼 클릭시 국적, 주언어 선택 페이지로 이동
    @GetMapping("member/lang")
    public String langPage() {
        return "member/lang"; // JSP: /WEB-INF/views/member/langNational.jsp
    }

    
    // 비밀번호 찾기 폼 (GET)
    @GetMapping("/member/findPassword")
    public String findPasswordForm() {
        return "member/findPassword"; // findPassword.jsp
    }

    
    
    // 국적, 언어 선택 후 약관동의 페이지로 이동
    @PostMapping("/lang")
    public String langSelect(
        @RequestParam("nationality") String nationality,
        @RequestParam("language") String language,
        HttpSession session,
        Model model
    ) {
        // 1. 세션이나 model에 값 저장 (필요 시)
        session.setAttribute("nationality", nationality);
        session.setAttribute("language", language);

        // 2. agree.jsp로 이동 (member/agree.jsp)
        return "member/agree";
    }

    @GetMapping("member/agree")
    public String langSelect() {
        return "member/agree";
    }

    // 약관동의 후 이메일 인증 페이지로 이동
    @PostMapping("/agree")
    public String agree(
        @RequestParam(value = "nationality", required = false) String nationality,
        @RequestParam(value = "language", required = false) String language,
        @RequestParam(value = "termsOfService", required = false) String termsOfService,
        @RequestParam(value = "privacyPolicy", required = false) String privacyPolicy,
        @RequestParam(value = "ageVerification", required = false) String ageVerification,
        HttpSession session,
        Model model
    ) {
        // 이전 단계에서 세션에 저장했다면 아래는 생략 가능
        if (nationality != null) session.setAttribute("nationality", nationality);
        if (language != null) session.setAttribute("language", language);

        // 필수 약관 동의 여부 체크 (서버에서도 한 번 더 검증)
        if (termsOfService == null || privacyPolicy == null || ageVerification == null) {
            model.addAttribute("error", "필수 약관에 모두 동의해야 합니다.");
            return "member/agree"; // 에러 메시지와 함께 다시 약관동의 페이지로
        }
        session.setAttribute("termsOfService", true);
        session.setAttribute("privacyPolicy", true);
        session.setAttribute("ageVerification", true);

        // 이메일 인증 페이지로 이동
        return "member/email";
    }
    
    
    
    

    // 로그아웃 처리 (/logout)
    @GetMapping("/logout")
    public String logout(HttpSession session, HttpServletResponse response) {
        session.invalidate();

        Cookie cookie = new Cookie("rememberId", "");
        cookie.setMaxAge(0);
        cookie.setPath("/");
        response.addCookie(cookie);

        return "redirect:/login";
    }

    // 회원가입 폼 이동 (/join)
    @GetMapping("/join")
    public String joinForm() {
        return "member/memberForm"; // 회원가입 폼 JSP
    }

    // 회원가입 처리 (/join, POST)
    @PostMapping("/join")
    public String join(MemberVO vo, 
                       @RequestParam(value = "userImgFile", required = false) MultipartFile file,
                       Model model) {
        try {
            if (file != null && !file.isEmpty()) {
                String uploadPath = servletContext.getRealPath("/uploads/profile/");
                String newFileName = memberService.saveProfileImage(file, uploadPath);
                vo.setUser_img(newFileName);
            }

            memberService.join(vo);
            model.addAttribute("msg", "회원가입이 완료되었습니다.");
            return "login"; // 가입 후 로그인 페이지 이동
        } catch (Exception e) {
            model.addAttribute("error", "회원가입 실패: " + e.getMessage());
            return "member/memberForm";
        }
    }

    // 이메일 중복 체크 (AJAX) (/idCheck, POST)
    @PostMapping("/idCheck")
    public String idCheck(@RequestParam("email") String email, Model model) {
        boolean isAvailable = memberService.idCheck(email);
        model.addAttribute("isAvailable", isAvailable);
        return "jsonView"; // JSON 응답 뷰
    }

    // 닉네임 중복 체크 (AJAX) (/nicknameCheck, POST)
    @PostMapping("/nicknameCheck")
    public String nicknameCheck(@RequestParam("nickname") String nickname, Model model) {
        boolean isAvailable = memberService.nicknameCheck(nickname);
        model.addAttribute("isAvailable", isAvailable);
        return "jsonView"; // JSON 응답 뷰
        
        
    
    }

    @GetMapping("/resetPassword")
    public String resetPassword() {
        // 특정 이메일의 비밀번호를 '123'으로 재설정
        ((MemberServiceImpl)memberService).updatePasswordForEmail("abc@gmail.com", "123");
        return "redirect:/login";
    }

    @GetMapping("/member/signup")
    public String signupForm(HttpSession session, Model model) {
        // 세션에서 국적과 언어 정보를 가져와서 모델에 추가
        String nationality = (String) session.getAttribute("nationality");
        String language = (String) session.getAttribute("language");
        
        if (nationality == null || language == null) {
            return "redirect:/member/lang"; // 국적/언어 선택 페이지로 리다이렉트
        }
        
        // 인증된 이메일 가져오기
        String verifiedEmail = (String) session.getAttribute("verifiedEmail");
        if (verifiedEmail != null) {
            model.addAttribute("verifiedEmail", verifiedEmail);
            model.addAttribute("emailVerified", true);
        }
        
        model.addAttribute("nationality", nationality);
        model.addAttribute("language", language);
        return "member/signup";
    }

    @PostMapping("/member/signup")
    public String signup(MemberVO vo, HttpSession session, RedirectAttributes rttr) {
        try {
            System.out.println("\n=== 회원가입 컨트롤러 시작 ===");
            System.out.println("요청 데이터 상세:");
            System.out.println("- 이메일: " + vo.getEmail());
            System.out.println("- 닉네임: " + vo.getNickname());
            System.out.println("- 이름: " + vo.getName());
            System.out.println("- 도시: " + vo.getCity());
            System.out.println("- 프로필 이미지: " + vo.getUser_img());
            
            // 세션에서 국적과 언어 정보를 가져와서 VO에 설정
            String nationality = (String) session.getAttribute("nationality");
            String language = (String) session.getAttribute("language");
            
            System.out.println("세션 데이터:");
            System.out.println("- 국적: " + nationality);
            System.out.println("- 언어: " + language);
            
            if (nationality == null || language == null) {
                throw new Exception("국적 또는 언어 정보가 없습니다. 처음부터 다시 시도해주세요.");
            }
            
            vo.setNationality(nationality);
            vo.setLanguage(language);
            vo.setStatus("ACTIVE"); // 기본 상태값 설정
            
            System.out.println("\n필수 필드 검증 시작");
            // 필수 필드 검증
            if (vo.getEmail() == null || vo.getEmail().trim().isEmpty()) {
                throw new Exception("이메일은 필수 입력 항목입니다.");
            }
            if (vo.getPassword() == null || vo.getPassword().trim().isEmpty()) {
                throw new Exception("비밀번호는 필수 입력 항목입니다.");
            }
            if (vo.getNickname() == null || vo.getNickname().trim().isEmpty()) {
                throw new Exception("닉네임은 필수 입력 항목입니다.");
            }
            if (vo.getName() == null || vo.getName().trim().isEmpty()) {
                throw new Exception("이름은 필수 입력 항목입니다.");
            }
            System.out.println("필수 필드 검증 완료\n");
            
            System.out.println("회원가입 서비스 호출 전 최종 데이터: " + vo.toString());
            memberService.join(vo);
            System.out.println("회원가입 서비스 호출 완료");
            
            // 회원가입 성공 후 세션 정리
            session.removeAttribute("nationality");
            session.removeAttribute("language");
            session.removeAttribute("verifiedEmail");
            
            System.out.println("=== 회원가입 컨트롤러 완료 ===\n");
            rttr.addFlashAttribute("message", "회원가입이 성공적으로 완료되었습니다. 로그인해주세요.");
            return "redirect:/member/signupConfirm";
            
        } catch (Exception e) {
            System.out.println("\n[에러] 회원가입 처리 중 오류 발생:");
            System.out.println("- 에러 메시지: " + e.getMessage());
            System.out.println("- 에러 타입: " + e.getClass().getName());
            e.printStackTrace();
            
            String errorMsg = e.getMessage();
            if (errorMsg.contains("이미 사용 중인 이메일")) {
                rttr.addFlashAttribute("error", "이미 등록된 이메일입니다. 다른 이메일을 사용해주세요.");
            } else if (errorMsg.contains("이미 사용 중인 닉네임")) {
                rttr.addFlashAttribute("error", "이미 사용 중인 닉네임입니다. 다른 닉네임을 사용해주세요.");
            } else {
                rttr.addFlashAttribute("error", "회원가입 처리 중 오류가 발생했습니다: " + e.getMessage());
            }
            
            // 입력 데이터 유지
            rttr.addFlashAttribute("memberVO", vo);
            return "redirect:/member/signup";
        }
    }

    @GetMapping("/member/signupConfirm")
    public String signupConfirm(Model model) {
        return "member/signupConfirm";
    }
}
