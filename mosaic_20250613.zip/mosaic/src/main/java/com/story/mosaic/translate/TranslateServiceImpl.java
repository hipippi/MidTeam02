package com.story.mosaic.translate;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import org.json.JSONObject;
import org.springframework.stereotype.Service;

@Service
public class TranslateServiceImpl implements TranslateService {

    private final String AUTH_KEY = "636ec227-8bf2-4b8e-8546-a2b48f0e04f5:fx";    

    @Override
    public String translate(String text, String targetLang) {
        try {
            URL url = new URL("https://api-free.deepl.com/v2/translate");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            
            String postData = "auth_key=" + AUTH_KEY +
                              "&text=" + URLEncoder.encode(text, "UTF-8") +
                              "&target_lang=" + targetLang +
                              "&tag_handling=html";            

            OutputStream os = conn.getOutputStream();
            //os.write(postData.getBytes());
            os.write(postData.getBytes(StandardCharsets.UTF_8));
            os.flush();
            
            //deepL 응답 코드
            int responseCode = conn.getResponseCode();
            System.out.println("DEEPL 응답 코드: " + responseCode);

            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                response.append(line);
            }

            JSONObject json = new JSONObject(response.toString());
            return json.getJSONArray("translations").getJSONObject(0).getString("text");

        } catch (Exception e) {
            e.printStackTrace();
            return "번역 실패";
        }
    }
}
