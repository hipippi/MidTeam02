package com.story.mosaic.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RequestMapping("/resources/upload")   
public class FileUploadController {

	@PostMapping("/story")
	@ResponseBody
    public Map<String, Object> uploadImage(@RequestParam("image") MultipartFile image,
                                           HttpServletRequest request) {
        Map<String, Object> result = new HashMap<>();

        try {
            // 파일 저장 경로 설정 (웹 서버 내부 디렉토리 또는 외부 경로)
            String uploadPath = request.getServletContext().getRealPath("/resources/upload/story/");
            File dir = new File(uploadPath);
            if (!dir.exists()) dir.mkdirs();

            // 원본 파일명에서 확장자 추출
            String originalFileName = image.getOriginalFilename();
            String extension = "";
            if (originalFileName != null && originalFileName.contains(".")) {
                extension = originalFileName.substring(originalFileName.lastIndexOf("."));
            }

            // 파일 이름을 UUID + 확장자로 지정 (한글 파일명 문제 해결)
            String fileName = UUID.randomUUID().toString() + extension;
            File file = new File(dir, fileName);
            image.transferTo(file);

            // 업로드된 파일의 접근 가능한 URL 반환
            //String imageUrl = request.getContextPath() + "/uploaded/story/" + fileName;
            String imageUrl = request.getContextPath() + "/resources/upload/story/" + fileName;
            result.put("url", imageUrl);
        } catch (Exception e) {
            result.put("error", "Upload failed: " + e.getMessage());
        }

        return result;
    }

    /**
     * 긴 파일명으로 요청이 올 때 짧은 UUID 파일명을 찾아서 서빙하는 메서드
     */
    @GetMapping("/story/{filename:.+}")
    public ResponseEntity<byte[]> serveImage(@PathVariable String filename, 
                                           HttpServletRequest request) {
        try {
            String uploadPath = request.getServletContext().getRealPath("/resources/upload/story/");
            
            // 요청된 파일이 직접 존재하는지 확인
            Path requestedFile = Paths.get(uploadPath, filename);
            if (Files.exists(requestedFile)) {
                byte[] imageBytes = Files.readAllBytes(requestedFile);
                String contentType = getContentType(filename);
                return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType(contentType))
                    .body(imageBytes);
            }
            
            // 직접 존재하지 않으면 UUID 파일들 중에서 찾기
            File dir = new File(uploadPath);
            if (dir.exists()) {
                File[] files = dir.listFiles();
                if (files != null) {
                    // 확장자 추출
                    String requestedExtension = "";
                    if (filename.contains(".")) {
                        requestedExtension = filename.substring(filename.lastIndexOf("."));
                    }
                    
                    // UUID 형태의 파일들 중에서 같은 확장자를 가진 파일 찾기
                    for (File file : files) {
                        String name = file.getName();
                        if (name.endsWith(requestedExtension) && isUUID(name.replace(requestedExtension, ""))) {
                            byte[] imageBytes = Files.readAllBytes(file.toPath());
                            String contentType = getContentType(name);
                            return ResponseEntity.ok()
                                .contentType(MediaType.parseMediaType(contentType))
                                .body(imageBytes);
                        }
                    }
                }
            }
            
            return ResponseEntity.notFound().build();
            
        } catch (IOException e) {
            return ResponseEntity.status(500).build();
        }
    }
    
    /**
     * 문자열이 UUID 형태인지 확인
     */
    private boolean isUUID(String str) {
        try {
            UUID.fromString(str);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }
    
    /**
     * 파일 확장자에 따른 Content-Type 반환
     */
    private String getContentType(String filename) {
        String extension = filename.substring(filename.lastIndexOf(".") + 1).toLowerCase();
        switch (extension) {
            case "jpg":
            case "jpeg":
                return "image/jpeg";
            case "png":
                return "image/png";
            case "gif":
                return "image/gif";
            case "webp":
                return "image/webp";
            default:
                return "application/octet-stream";
        }
    }
}
