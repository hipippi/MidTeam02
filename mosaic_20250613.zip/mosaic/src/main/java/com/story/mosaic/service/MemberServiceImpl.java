package com.story.mosaic.service;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.story.mosaic.model.MemberVO;
import com.story.mosaic.repo.MemberDAO;

@Service
public class MemberServiceImpl implements MemberService {

    @Autowired
    private MemberDAO memberDAO;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public MemberVO login(MemberVO vo) {
        System.out.println("=== 로그인 디버그 ===");
        System.out.println("입력된 이메일: " + vo.getEmail());
        System.out.println("입력된 비밀번호: " + vo.getPassword());
        
        // [임시코드 - 주석처리]
        // 비밀번호를 다시 암호화하여 저장
        // updatePasswordForEmail("abc@gmail.com", "123");
        // System.out.println("비밀번호 재설정 완료");
        
        MemberVO member = memberDAO.findByEmail(vo.getEmail());
        System.out.println("DB에서 찾은 회원: " + (member != null ? "있음" : "없음"));
        
        if (member != null) {
            System.out.println("DB 저장된 이메일: " + member.getEmail());
            System.out.println("DB 저장된 비밀번호: " + member.getPassword());
            boolean matches = passwordEncoder.matches(vo.getPassword(), member.getPassword());
            System.out.println("비밀번호 매칭 결과: " + matches);
            System.out.println("입력된 비밀번호: " + vo.getPassword());
            System.out.println("DB 비밀번호: " + member.getPassword());
            
            if (matches) {
                return member; // 로그인 성공
            }
        }
        return null; // 로그인 실패
    }

    // 비밀번호 업데이트 메서드 추가
    public void updatePasswordForEmail(String email, String rawPassword) {
        Map<String, String> params = new HashMap<>();
        params.put("email", email);
        params.put("password", passwordEncoder.encode(rawPassword));
        memberDAO.updatePassword(params);
    }

    @Override
    @Transactional
    public void join(MemberVO vo) {
        try {
            System.out.println("\n=== 회원가입 서비스 시작 ===");
            System.out.println("입력된 회원 정보 상세:");
            System.out.println("- 이메일: " + vo.getEmail());
            System.out.println("- 닉네임: " + vo.getNickname());
            System.out.println("- 이름: " + vo.getName());
            System.out.println("- 국적: " + vo.getNationality());
            System.out.println("- 언어: " + vo.getLanguage());
            System.out.println("- 도시: " + vo.getCity());
            System.out.println("- 상태: " + vo.getStatus());
            
            // 이메일 중복 체크
            System.out.println("\n이메일 중복 체크 시작");
            if (!idCheck(vo.getEmail())) {
                throw new RuntimeException("이미 사용 중인 이메일입니다.");
            }
            System.out.println("이메일 중복 체크 통과");
            
            // 닉네임 중복 체크
            System.out.println("\n닉네임 중복 체크 시작");
            if (!nicknameCheck(vo.getNickname())) {
                throw new RuntimeException("이미 사용 중인 닉네임입니다.");
            }
            System.out.println("닉네임 중복 체크 통과");
            
            // 비밀번호 암호화
            System.out.println("\n비밀번호 암호화 시작");
            String encodedPassword = passwordEncoder.encode(vo.getPassword());
            vo.setPassword(encodedPassword);
            System.out.println("비밀번호 암호화 완료");
            
            // DB 저장
            System.out.println("\nDB 저장 시도");
            memberDAO.insertMember(vo);
            System.out.println("DB 저장 완료");
            
            System.out.println("=== 회원가입 서비스 완료 ===\n");
        } catch (Exception e) {
            System.out.println("\n[에러] 회원가입 서비스 오류 발생:");
            System.out.println("- 에러 메시지: " + e.getMessage());
            System.out.println("- 에러 타입: " + e.getClass().getName());
            e.printStackTrace();
            throw new RuntimeException("회원가입 처리 중 오류가 발생했습니다: " + e.getMessage());
        }
    }

    @Override
    public boolean idCheck(String email) {
        System.out.println("이메일 중복 체크 결과: " + memberDAO.emailCheck(email));
        return memberDAO.emailCheck(email) == 0;  // 0이면 중복 없음 (사용 가능)
    }

    @Override
    public boolean nicknameCheck(String nickname) {
        System.out.println("닉네임 중복 체크 결과: " + memberDAO.nicknameCheck(nickname));
        return memberDAO.nicknameCheck(nickname) == 0;  // 0이면 중복 없음 (사용 가능)
    }

    @Override
    public String saveProfileImage(MultipartFile file, String uploadPath) throws Exception {
        File folder = new File(uploadPath);
        if (!folder.exists()) {
            folder.mkdirs();
        }

        String originalName = file.getOriginalFilename();
        String ext = originalName.substring(originalName.lastIndexOf("."));
        String newFileName = UUID.randomUUID().toString() + ext;

        file.transferTo(new File(uploadPath + newFileName));

        return newFileName;
    }

    @Override
    public String registerSnsUser(String email, String nickname) {
        MemberVO vo = new MemberVO();

        // UUID로 user_id 직접 생성
        vo.setUser_id(UUID.randomUUID().toString());

        vo.setEmail(email);
        vo.setNickname(nickname);
        // 필요시 추가 필드 세팅 가능

        memberDAO.insertMember(vo);  // DB에 회원 저장

        return vo.getUser_id();      // 생성한 user_id 반환
    }
    
    @Override
    public MemberVO findByUserId(String userId) {
        return memberDAO.findByUserId(userId);
    }

    
    
}
