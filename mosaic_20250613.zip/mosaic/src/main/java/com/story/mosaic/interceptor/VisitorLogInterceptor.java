package com.story.mosaic.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import com.story.mosaic.model.VisitorLogVO;
import com.story.mosaic.service.VisitorLogService;

@Component
public class VisitorLogInterceptor implements HandlerInterceptor {

    @Autowired
    private VisitorLogService visitorLogService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {

        //  관리자 페이지는 방문자 통계 제외
        String uri = request.getRequestURI();
        if (uri.startsWith("/admin")) {
            return true; // 관리자 영역은 기록 제외
        }

        // 이미 기록된 방문자인지 세션으로 체크
        if (request.getSession().getAttribute("visitorLogged") != null) {
            return true; // 중복 기록 방지
        }

        // 최초 방문자 기록
        VisitorLogVO vo = new VisitorLogVO();
        vo.setUser_ip(request.getRemoteAddr());
        vo.setPage(request.getRequestURI());
        vo.setUser_agent(request.getHeader("User-Agent"));
        vo.setSession_id(request.getSession().getId());

        visitorLogService.insertVisitorLog(vo);

        // 세션 플래그 설정
        request.getSession().setAttribute("visitorLogged", "Y");

        return true;
    }
}
