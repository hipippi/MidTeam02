package com.story.mosaic.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.story.mosaic.model.CommentVO;
import com.story.mosaic.service.CommentService;

@RestController
@RequestMapping("/comment")
public class CommentController {

    @Autowired
    private CommentService commentService;

    // 댓글 목록
    @GetMapping("/list")
    public Map<String, Object> getCommentList(@RequestParam("post_id") Integer post_id,
                                          @RequestParam(defaultValue = "1") int page,
                                          @RequestParam(defaultValue = "5") int size) {
        Map<String, Object> result = new HashMap<>();
        
        // 댓글 목록 조회
        List<CommentVO> comments = commentService.getCommentsByPostIdPaged(post_id, page, size);
        
        // 전체 댓글 수 조회
        int totalComments = commentService.countCommentsByPostId(post_id);
        int totalPages = (int) Math.ceil((double) totalComments / size);
        
        result.put("comments", comments);
        result.put("totalPages", totalPages);
        result.put("currentPage", page);
        result.put("totalComments", totalComments);
        
        return result;
    }

    // 댓글 등록
    @PostMapping("/add")
    public Map<String, Object> addComment(@ModelAttribute CommentVO co, HttpSession session) {
        Map<String, Object> result = new HashMap<>();
        Object loginMember = session.getAttribute("loginMember");
        if (loginMember == null) {
            result.put("status", "fail");
            result.put("message", "로그인 필요");
            return result;
        }

        commentService.insertComment(co);
        result.put("status", "success");
        return result;
    }

    // ✅ 댓글 수정
    @PostMapping("/update")
    public Map<String, Object> updateComment(@RequestBody CommentVO co, HttpSession session) {
        Map<String, Object> result = new HashMap<>();
        Object loginMember = session.getAttribute("loginMember");

        if (loginMember == null) {
            result.put("status", "fail");
            result.put("message", "로그인 필요");
            return result;
        }

        commentService.updateComment(co);
        result.put("status", "success");
        return result;
    }

    // ✅ 댓글 삭제
    @PostMapping("/delete")
    public Map<String, Object> deleteComment(@RequestBody CommentVO co, HttpSession session) {
        Map<String, Object> result = new HashMap<>();
        Object loginMember = session.getAttribute("loginMember");

        if (loginMember == null) {
            result.put("status", "fail");
            result.put("message", "로그인 필요");
            return result;
        }

        commentService.deleteComment(co);
        result.put("status", "success");
        return result;
    }
}
