package com.story.mosaic.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.story.mosaic.model.AdminReportVO;
import com.story.mosaic.repo.NoticeDAO;
import com.story.mosaic.repo.AdminReportDAO;

@Service
public class AdminReportServiceImpl implements AdminReportService {
	@Autowired
	private AdminReportDAO reportDAO;

	@Override
	public List<AdminReportVO> getReportList() {
		
		return reportDAO.getReportList();
	}

	@Override
	public int updateReportStatus(AdminReportVO vo) {
		
		return reportDAO.updateReportStatus(vo);
	}
	//DAO 를 통해 신고글 갯수 조회
	@Override
	public int getReportCount() {
	
		return reportDAO.getReoportCount();
	}


}
