package com.story.mosaic.model;
import java.sql.Clob;
import java.util.Date;
import java.util.List;
import lombok.Data;

@Data	
public class StoryVO {
	//멤버 변수명 네이밍 규칙 => db 칼럼명과 동일하게
	private Integer		post_id;			//게시글 고유번호	post_id
	private String		user_id;			//게시글 작성자	user_id
	private String 		title;				//게시글 제목 	title
	private String		content;			//게시글내용 	content
	private String  	content_translated;	//게시글 번역결과	content_translated
	private Integer		views;				//조회수 		views
	private String		category;			//게시글 카테고리 category
	private Date		write_date;			//게시글 작성일	write_date
	private Integer		story_comment;  	//댓글수		story_comment	
	
	private String		language;			//기본 언어		
	private String		language_target;	//번역 언어
	private String		tags; 				//태그
	private String		thumb_url; 			//첫번째 등록 이미지 url
	private String		summary; 			//웹에디터 입력값에서 텍스트만 짧게 추출
	
	private String		nickname;			//게시글 작성자	NICKNAME
	//private String		location_id;		
	
	// story객체에만 있는 변수. DB에는 없어도 됨
    private List<String> tagList;
    private Integer rnum;
}