package com.story.mosaic.service;

import java.util.List;

import com.story.mosaic.model.AdminReportVO;

public interface AdminReportService {
	//신고 목록 조회 
	public List<AdminReportVO> getReportList();

	//신고 처리 
	public int updateReportStatus(AdminReportVO vo);
	
	//신고글 총 갯수 
	public int getReportCount();

}
