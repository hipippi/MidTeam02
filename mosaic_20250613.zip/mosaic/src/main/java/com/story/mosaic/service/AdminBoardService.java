package com.story.mosaic.service;

public interface AdminBoardService {
	//게시글 삭제(report_id)
	public int deletePostById(int post_id);
}
