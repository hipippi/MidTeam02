package com.story.mosaic.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.story.mosaic.model.AdminGroupVO;
import com.story.mosaic.repo.AdminGroupDAO;

@Service
public class AdminGroupServiceImpl implements AdminGroupService {

	@Autowired
	private AdminGroupDAO adminGroupDAO; // AdminGroupDAO를 자동으로 주입 받아서 DB와 연결

	@Override
	public AdminGroupVO getGroupDetail(int group_id) {
		// DAO를 통해 DB에서 해당 ID의 그룹 정보를 가져옴
		return adminGroupDAO.getAdminGroupById(group_id);
	}
	
	
}
