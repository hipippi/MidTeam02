package com.story.mosaic.service;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.story.mosaic.model.GroupPartVO;
import com.story.mosaic.model.GroupGreetingVO;
import com.story.mosaic.model.GroupVO;

public interface GroupService {
	void insertGroup(GroupVO vo, HttpServletRequest request);
	List<GroupVO> getGroupList(HashMap map);
	GroupVO getGroup(GroupVO vo);
	void deleteGroup(GroupVO vo);
	void updateGroup(GroupVO vo, HttpServletRequest request);
	void insertGroupPart(GroupPartVO pvo);
//	List<GroupPartVO> getGroupPartList();
	GroupPartVO getGroupPart(GroupPartVO pvo);
	void deleteGroupById(GroupVO vo);
	void leaveGroupPart(GroupPartVO pvo);
	List<GroupPartVO> getGroupPartList(GroupPartVO pvo);
	Integer deleteGroupPart(Integer part_id);
	GroupGreetingVO getGroupGreeting(GroupGreetingVO rvo);
	void deleteGroupGreeting(GroupGreetingVO gvo);
	void insertGroupGreeting(GroupGreetingVO gvo);
	List<GroupGreetingVO> getGroupGreetingList(GroupGreetingVO gvo);

}
