package com.story.mosaic.translate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TranslateController {	
    @Autowired
    private TranslateService translateService;    
    @PostMapping(value = "translateText.do", produces = "text/plain; charset=UTF-8")	//번역결과 ajax 문자 깨짐 방지
    public String translateText(@RequestParam String text,
                                @RequestParam String targetLang) {    	
    	System.out.println("controller1 in translateText.do");
        return translateService.translate(text, targetLang);
    }
    
    @Autowired
    private TranslateFullService translateFullService;
    
    @PostMapping("/changeLang")     //전체사이트 번역 용도
    //@PostMapping(value = "/translateText.do", produces = "text/plain; charset=UTF-8")	//위에 오류나서 임시 사용
    public String changeLang(@RequestParam String text,
        @RequestParam String targetLang) {
		System.out.println("controller2 in translateText.do");		
		return translateFullService.translate(text, targetLang);
	}
}
	