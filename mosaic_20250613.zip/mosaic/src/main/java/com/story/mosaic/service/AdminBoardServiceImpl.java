package com.story.mosaic.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.story.mosaic.repo.AdminBoardDAO;

@Service
public class AdminBoardServiceImpl implements AdminBoardService{

    @Autowired
    private AdminBoardDAO adminBoardDAO;

	@Override
	public int deletePostById(int post_id) {
	
		return adminBoardDAO.deletePostById(post_id);
	}
    

}
