package com.story.mosaic.repo;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.story.mosaic.model.AdminReportVO;

@Mapper
public interface AdminReportDAO {
	//신고 목록 조회 
	public List<AdminReportVO> getReportList();

	//신고 처리 
	public int updateReportStatus(AdminReportVO vo);
	
	//신고글 총 갯수 
	public int getReoportCount();

}
