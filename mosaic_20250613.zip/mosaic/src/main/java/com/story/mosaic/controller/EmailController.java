package com.story.mosaic.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.story.mosaic.service.EmailService;

@Controller
@RequestMapping
public class EmailController {

    @Autowired
    private EmailService emailService;

    // 인증메일 전송
    @PostMapping("/email/sendVerificationEmail")
    @ResponseBody
    public String sendVerificationEmail(@RequestParam String email, HttpSession session) {
        System.out.println("sendVerificationEmail called with email = " + email);
        try {
            // 인증번호 생성 및 메일 발송 (코드 반환)
            String code = emailService.sendVerificationEmail(email);
            // 세션에 인증번호와 이메일 저장
            session.setAttribute("verifyCode", code);
            session.setAttribute("verifyEmail", email);
            System.out.println("Verification code sent: " + code);
            return "success";
        } catch (Exception e) {
            e.printStackTrace();
            return "fail";
        }
    }

    // 인증번호 검증
    @PostMapping("/email/verifyCode")
    @ResponseBody
    public String verifyCode(@RequestParam String email, @RequestParam String code, HttpSession session) {
        String savedCode = (String) session.getAttribute("verifyCode");
        String savedEmail = (String) session.getAttribute("verifyEmail");

        if (savedCode != null && savedEmail != null &&
                savedEmail.equals(email) && savedCode.equals(code)) {
            // 인증 성공 시 세션에 인증된 이메일 저장
            session.setAttribute("verifiedEmail", email);
            // 인증에 사용된 임시 데이터는 제거
            session.removeAttribute("verifyCode");
            session.removeAttribute("verifyEmail");
            return "verified";
        } else {
            return "invalid";
        }
    }
    
 
}
