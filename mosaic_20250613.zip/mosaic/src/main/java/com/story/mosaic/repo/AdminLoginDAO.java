package com.story.mosaic.repo;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.story.mosaic.model.AdminLoginVO;

@Mapper
public interface AdminLoginDAO {
    // 이메일로 관리자 정보 조회
    AdminLoginVO findByEmail(String email);
}
