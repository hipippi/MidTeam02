package com.story.mosaic.model;

import java.util.Date;

import lombok.Data;

@Data
public class GroupGreetingVO {
	private Integer greeting_id;
	private String user_id;
	private String nickname;
	private Integer group_id;
	private Date greeting_date;
	private String greeting_content;
}
