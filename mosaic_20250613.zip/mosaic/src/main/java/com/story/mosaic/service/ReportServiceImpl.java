package com.story.mosaic.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.story.mosaic.model.ReportVO;
import com.story.mosaic.repo.NoticeDAO;
import com.story.mosaic.repo.ReportDAO;

@Service
public class ReportServiceImpl implements ReportService {
	@Autowired
	private ReportDAO reportDAO;

	@Override
	public List<ReportVO> getReportList() {
		
		return reportDAO.getReportList();
	}

	@Override
	public int updateReportStatus(ReportVO vo) {
		
		return reportDAO.updateReportStatus(vo);
	}
	
}
