package com.story.mosaic.service;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.story.mosaic.model.GroupPartVO;
import com.story.mosaic.model.GroupGreetingVO;
import com.story.mosaic.model.GroupVO;
import com.story.mosaic.repo.GroupDAO;

@Service("groupService")
public class GroupServiceImpl implements GroupService {
	
	@Autowired
	private GroupDAO groupDAO;

	@Transactional
	public void insertGroup(GroupVO vo, HttpServletRequest request) {
		//user_id는 앞에서 세팅완료
		fileUpload(vo, request);
		groupDAO.insertGroup(vo);
		
		GroupPartVO pvo = new GroupPartVO();
		pvo.setGroup_id(vo.getGroup_id());
		System.out.println(vo.getGroup_id());
		pvo.setUser_id(vo.getUser_id());
		pvo.setPart_status("host");
		System.out.println("user_id: " + pvo.getUser_id());
		System.out.println("group_id: " + pvo.getGroup_id());
		System.out.println("part_status: " + pvo.getPart_status());
		
		groupDAO.insertGroupPart(pvo);
	}
	

	@Override
	public List<GroupVO> getGroupList(HashMap map){
		return groupDAO.getGroupList(map);
		
	}

	@Override
	public GroupVO getGroup(GroupVO vo) {
		return groupDAO.getGroup(vo);
	}

	@Transactional
	public void deleteGroup(GroupVO vo) {
		groupDAO.deleteGroupById(vo.getGroup_id());
		groupDAO.deleteGroup(vo);		
	}

	@Override
	public void updateGroup(GroupVO vo, HttpServletRequest request) {
		fileUpload(vo, request);
		groupDAO.updateGroup(vo);
		
	}

	@Override
	public void deleteGroupById(GroupVO vo) {
		groupDAO.deleteGroupById(vo.getGroup_id());
		
	}
	
	private void fileUpload(GroupVO vo, HttpServletRequest request) {
		String uploadPath = request.getServletContext().getRealPath("/resources/upload/group/groupimages");
		
		// 기존 폴더가 없을 시 자동으로 폴더생성
		File folder = new File(uploadPath);
		if (!folder.exists()) folder.mkdirs();

		
		//파일 저장 처리
		MultipartFile file = vo.getFile();
		
		if (file != null && !file.isEmpty()) {
			try {
				
				String group_image = file.getOriginalFilename();
				UUID uuid = UUID.randomUUID();
				String group_irealname = uuid.toString() + "_" + group_image;
				//랜덤 파일명 생성하여 저장

	            File dest = new File(uploadPath, group_irealname);
	            file.transferTo(dest); // 저장
	            
	            System.out.println("File saved at: " + dest.getAbsolutePath());

	            vo.setGroup_image(group_image);
	            vo.setGroup_irealname(group_irealname);
	            vo.setGroup_isize(file.getSize()); //사이즈 가져와서 세팅
	            
	            System.out.println("group_image: " + vo.getGroup_image());
	            System.out.println("group_isize: " + vo.getGroup_isize());
	            System.out.println("group_irealname: " + vo.getGroup_irealname());

			} catch (Exception e) {
	            e.printStackTrace();
	        }
		}
		
	
		
	}
	
	@Override
	public void insertGroupPart(GroupPartVO pvo) {
		groupDAO.insertGroupPart(pvo);
	}

	@Override
	public List<GroupPartVO> getGroupPartList(GroupPartVO pvo) {
		return groupDAO.getGroupPartList(pvo);
	}

	@Override
	public GroupPartVO getGroupPart(GroupPartVO pvo) {
		return groupDAO.getGroupPart(pvo);
	}

	@Override
	public Integer deleteGroupPart(Integer part_id) {
		System.out.println("서비스: " + part_id);
		return groupDAO.deleteGroupPart(part_id);
	}



	@Override
	public void leaveGroupPart(GroupPartVO pvo) {
		groupDAO.leaveGroupPart(pvo);
	}


	@Override
	public void insertGroupGreeting(GroupGreetingVO gvo) {
		groupDAO.insertGroupGreeting(gvo);
		
	}


	@Override
	public GroupGreetingVO getGroupGreeting(GroupGreetingVO gvo) {
		return groupDAO.getGroupGreeting(gvo);
	}


	@Override
	public void deleteGroupGreeting(GroupGreetingVO gvo) {
		groupDAO.deleteGroupGreeting(gvo);
		
	}


	@Override
	public List<GroupGreetingVO> getGroupGreetingList(GroupGreetingVO gvo) {
		return groupDAO.getGroupGreetingList(gvo);
	}
	
	
}
