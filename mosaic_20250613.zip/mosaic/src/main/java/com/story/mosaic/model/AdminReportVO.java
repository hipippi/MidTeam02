package com.story.mosaic.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AdminReportVO {
	private int report_id;         // 신고 ID
	private String target_type;    // 대상 유형
	private int target_id;         // 대상 ID
	private String reason;         // 신고 사유
	private String report_date;    // 신고 날짜
	private String status;         // 처리 상태 
	private String post_title; 

	
}
