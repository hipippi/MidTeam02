package com.story.mosaic.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.story.mosaic.model.AdminLoginVO;
import com.story.mosaic.model.AdminManagerVO;
import com.story.mosaic.service.AdminManagerService;

@Controller
@RequestMapping("/admin")
public class AdminManagerController {
	
	@Autowired
	private AdminManagerService adminManagerService;
	
	//등록된 관리자 리스트 목록
	@GetMapping("/adminList")
	public String getAdminList(Model model) {
		List<AdminManagerVO> list = adminManagerService.getAdminList(); //전체목록 조회
		model.addAttribute("adminList", list); //jsp에 전달
		model.addAttribute("currentPage", "admin"); 
		return "admin/AdminManagerList"; 
	}
	//  관리자 등록 처리 (Ajax + JSON)
	@PostMapping("/registerProc")
	@ResponseBody
	public Map<String, Object> registerAdmin(@RequestBody AdminManagerVO vo, HttpSession session) {
	    Map<String, Object> response = new HashMap<>();
	    try {
	        // 로그인한 관리자 세션 정보 가져오기
	    	AdminLoginVO loginAdmin = (AdminLoginVO) session.getAttribute("adminLogin");

	        // 최고관리자가 아닌 경우 권한을 '일반'으로 강제 설정
	        if (!"최고관리자".equals(loginAdmin.getAdmin_level())) {
	            vo.setAdmin_level("일반");
	        }

	        adminManagerService.insertAdmin(vo);
	        response.put("result", "success");
	    } catch (Exception e) {
	        response.put("result", "fail");
	        response.put("error", e.getMessage());
	    }
	    return response;
	}
	// 관리자 삭제
	@GetMapping("/delete")
	public String deleteAdmin(@RequestParam("admin_id") int admin_id,
	                          HttpSession session,
	                          RedirectAttributes rttr) {

	    AdminLoginVO loginAdmin = (AdminLoginVO) session.getAttribute("adminLogin");

	    // 최고관리자만 삭제 가능
	    if (!"최고관리자".equals(loginAdmin.getAdmin_level())) {
	        rttr.addFlashAttribute("error", "삭제 권한이 없습니다.");
	        return "redirect:/admin/adminList";
	    }

	    // 삭제 전 공지사항 존재 여부 체크
	    int noticeCount = adminManagerService.countNoticesByAdmin(admin_id);
	    if (noticeCount > 0) {
	        rttr.addFlashAttribute("error", "해당 관리자가 작성한 공지사항이 " + noticeCount + "건 존재하여 삭제할 수 없습니다.");
	        return "redirect:/admin/adminList";
	    }

	    adminManagerService.deleteAdmin(admin_id);
	    return "redirect:/admin/adminList";
	}

}
