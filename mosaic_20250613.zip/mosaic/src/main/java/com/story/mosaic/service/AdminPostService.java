package com.story.mosaic.service;

import java.util.List;

import com.story.mosaic.model.AdminPostVO;

public interface AdminPostService {
	// 타입별(story/group) 게시물 조회
	public List<AdminPostVO> getPostByType(String type);
	// 공개/비공개 상태 변경
    public void updateStatus(int postId, String type, String status);  
    // 게시물 삭제
    public void deletePost(int postId, String type);  
    
    //스토리 마당 게시물수 조회
    public int getStoryPostCount();
    
    //모임 게시물 수 조회
    public int getGroupPostCount();
    
    //모임 게시물 삭제
    public void deleteGroupPost(int groupId);

}
