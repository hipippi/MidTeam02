package com.story.mosaic.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.story.mosaic.repo.VisitorLogDAO;

@Controller
public class VisitorLogController {

	@Autowired
	private VisitorLogDAO visitorLogDAO;
	
	@GetMapping("admin/visitorStats")
	@ResponseBody
	public List<Map<String, Object>> getMonthlyStats(){
		return visitorLogDAO.getMonthlyVisitorStats();
	}
	@GetMapping("admin/visitorStatsWeekly")
	@ResponseBody
	public List<Map<String, Object>> getWeeklyStats(){
	    return visitorLogDAO.getWeeklyVisitorStats();
	}

    @GetMapping("admin/visitorStatsYearly")
    @ResponseBody
    public List<Map<String, Object>> getYearlyStats() {
        return visitorLogDAO.getYearlyVisitorStats();
    }
}

