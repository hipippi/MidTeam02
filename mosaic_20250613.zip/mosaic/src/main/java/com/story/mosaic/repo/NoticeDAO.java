package com.story.mosaic.repo;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.story.mosaic.model.NoticeVO;

@Mapper
public interface NoticeDAO {
	//리스트 메서드
	
	public List<NoticeVO> getNoticeList();
	
	//등록 메서드
	public void insertNotice(NoticeVO vo);
	
	//상세보기 메서드
	public NoticeVO getNoticeById(int notice_id);
	
	//공지사항 수정
	public void updateNotice(NoticeVO vo);
	
	//공지사항 삭제
	public void deleteNotice(int notice_id);
	
	//조회수 증가
	public void increaseViews(int notice_id);
	
	//최신 공지사항 조회
	public List<NoticeVO> getRecentNotices();
	
	//공지사항 카테고리 조회
	List<NoticeVO> searchNotices(@Param("keyword") String keyword, @Param("notice_type") String noticeType);

	
}
