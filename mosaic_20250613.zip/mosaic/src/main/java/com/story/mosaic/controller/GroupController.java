package com.story.mosaic.controller;



import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.story.mosaic.model.GroupPartVO;
import com.story.mosaic.model.GroupGreetingVO;
import com.story.mosaic.model.GroupVO;
import com.story.mosaic.service.GroupService;

@Controller
@RequestMapping("/group")
public class GroupController {
	
	@Autowired
	private GroupService groupService;
	
	@RequestMapping("/groupMain") //그룹 메인 페이지로 이동
	public void groupMain(Model m, String searchCondition, String searchKeyword){
		
		HashMap map = new HashMap();
		map.put("searchCondition", searchCondition);
		map.put("searchKeyword", searchKeyword);
		List<GroupVO> result = groupService.getGroupList(map);
		m.addAttribute("groupList", result);
	}
	
	@RequestMapping("/groupDetail") // 그룹페이지 상세보기
	public String groupDetail(GroupVO vo, Model m, HttpSession session) {
	    // 세션에서 로그인 유저 정보 가져오기
	    String userId = (String) session.getAttribute("user_id");
	    System.out.println(session.getId());
	    System.out.println("✅ user_id from session: " + userId);
	    Integer groupId = vo.getGroup_id();
	    
	    // 그룹 정보 가져오기
		GroupVO result = groupService.getGroup(vo);
		m.addAttribute("getGroup", result); // jsp에서 ${getGroup.group_id} 등으로 접근		
		
		String partStatus = "non-participant";
		
		if(userId != null && !userId.isEmpty()) { //session에서 id체크
			GroupPartVO pvo = new GroupPartVO();
			pvo.setUser_id(userId);
			pvo.setGroup_id(groupId);
			// group_part에서 user_id, group_id로 part_status 조회
			GroupPartVO part = groupService.getGroupPart(pvo);
			System.out.println("[/group/groupDetail][groupDetail]" + pvo.toString());
	        if (part != null) {
	        	partStatus = part.getPart_status();// host 또는 participant
	        } else {
	        	System.out.println("참여자 아님");
	        }

	    }
		
		System.out.println(partStatus.toString());
		
	    // 5. 역할 전달
	    m.addAttribute("part_status", partStatus);
		return "group/groupDetail";
	}
	
	@RequestMapping("/insertForm") //그룹등록 페이지로 이동
	public String insertForm(GroupVO vo, Model m) {
		if(vo.getGroup_id() != null) {
			m.addAttribute("getGroup", groupService.getGroup(vo));	
		}
	    return "group/insertForm";
	}
	
	@PostMapping("/insertGroup") //그룹등록
	public String insertGroup(GroupVO vo, HttpServletRequest request){
	    // 사용자가 입력한 그룹 제목 로그 출력 (디버깅용)
		String userId = (String) request.getSession().getAttribute("user_id"); //로그인한 사용자의 id 값을 불러옴
		
	    if (userId == null) {
	        System.out.println("⚠️ 세션이 존재하지 않습니다.");
	    } else {
	        System.out.println("✅ 세션에서 가져온 user_id: " + userId);
	        vo.setUser_id(userId);
	    }

	    System.out.println("입력 전 VO: " + vo);
		
		//파일 업로드 경로
		//DB저장
		groupService.insertGroup(vo, request);
		return "redirect:/group/groupMain";
	}
	
	@RequestMapping("/deleteGroup")
	public String deleteGroup(GroupVO vo) {
		groupService.deleteGroup(vo);
		return "redirect:/group/groupMain";
	}
	
	@PostMapping("/updateGroup")
	public String updateGroup(GroupVO vo, Model m, HttpServletRequest request) {
		HttpSession session = request.getSession(false); // session이 없으면 새로 만들지 않고 null반환
		if(session == null || session.getAttribute("user_id") == null) { //로그인 체크
			return "redirect:/member/login";
		} 
		
		String userId = (String) request.getSession().getAttribute("user_id");
		GroupVO gmember = groupService.getGroup(vo);
		if(gmember == null) { //그룹id 확인
			return "redirect:/group/groupDetail/?group_id=" + vo.getGroup_id();
		}
		
		if(!userId.equals(gmember.getUser_id())) { // getGroup통해서 id값 끌고옴 -> 주최자의 아이디만 존재하므로 이것만으로 체크가능
			return "redirect:/group/groupDetail/?group_id=" + vo.getGroup_id();
		}
		m.addAttribute("getGroup", groupService.getGroup(vo)); // Model 정보 저장
		groupService.updateGroup(vo, request); //update method 호출
		return "redirect:/group/groupDetail/?group_id=" + vo.getGroup_id();
	}

	//----------------------group파트----------------------------------------------
	
	
	
	
	/*****************************************************
	 * 참가자 등록 파트
	 */
	
	@RequestMapping("/insertGroupPart")
	public String insertGroupPart(GroupPartVO pvo, Model m, HttpSession session) {
	    System.out.println("컨트롤러 실행됨");
		String userId = (String) session.getAttribute("user_id");
		System.out.println(userId);
	    if (session == null || userId == null) {
	    	return "redirect:/member/login"; 
	    }
	    System.out.println(userId);
	    System.out.println("✅ user_id from session: " + userId);
	    Integer groupId = pvo.getGroup_id();
	    System.out.println(groupId);
	    // 그룹 정보 가져오기
		
		pvo.setUser_id(userId);
		pvo.setGroup_id(groupId);
		pvo.setPart_status("participant");
		// group_part에서 user_id, group_id로 part_status 조회
		
		System.out.println(userId);
		System.out.println(groupId);
		
		groupService.insertGroupPart(pvo);
	    System.out.println(pvo.getGroup_id());
	    return "redirect:/group/groupDetail/?group_id=" + pvo.getGroup_id();
	}
	
	@GetMapping("/groupPartList")
	@ResponseBody
	public Map<String, Object> groupPartList(GroupPartVO pvo, HttpSession session) {
		List<GroupPartVO> result = groupService.getGroupPartList(pvo);
		
	    // 세션에서 로그인된 사용자 ID 추출
	    String userId = (String) session.getAttribute("user_id");

	    // 기본값
	    String loginUserStatus = "member"; // 또는 null

	    // 기존 리스트에서 로그인한 사용자의 part_status 찾기
	    for (GroupPartVO vo : result) {
	        if (vo.getUser_id().equals(userId)) {
	            loginUserStatus = vo.getPart_status();
	            break;
	        }
	    }

	    Map<String, Object> response = new HashMap<>();
	    response.put("partList", result);
	    response.put("loginUserStatus", loginUserStatus);

	    return response;
	}
	
	@DeleteMapping("/deleteGroupPart/{part_id}")
	@ResponseBody
	public String deleteGroupPart(@PathVariable("part_id") Integer part_id) {
		System.out.println("삭제할 댓글번호: " + part_id);
		groupService.deleteGroupPart(part_id);
		return "success";
	}
	
	@RequestMapping("/leaveGroup")
	public String leaveGroupPart(GroupPartVO pvo, HttpSession session) {
	    String userId = (String) session.getAttribute("user_id");
	    Integer groupId = pvo.getGroup_id();
		pvo.setUser_id(userId);
		pvo.setGroup_id(groupId);

		System.out.println(pvo.getGroup_id());
		System.out.println(pvo.getUser_id());
		groupService.leaveGroupPart(pvo);
		return "redirect:/group/groupMain";
	}

//--------------------------------------------참가자 파트-------------------------------------------
	
	/*****************************************************
	 * 사진올리기
	 */
	
	@PostMapping("/insertGroupGreeting")
	public String insertGroupGreeting(@RequestParam("group_id") int groupId, GroupGreetingVO gvo, HttpSession session){
	    String userId = (String) session.getAttribute("user_id");
	    
	    if(userId == null) {
	    	return "redirect:/member/login";
	    }
	    // 참가 여부 확인용 VO 생성
	    GroupPartVO partCheck = new GroupPartVO();
	    partCheck.setGroup_id(groupId);
	    partCheck.setUser_id(userId);

	    GroupPartVO participant = groupService.getGroupPart(partCheck);
	    if (participant == null) {
	        // 해당 참가자 아님 → 리뷰 작성 불가
	        return "redirect:/group/groupDetail/?group_id=" + groupId;
	    }
	    gvo.setUser_id(userId);
	    gvo.setGroup_id(groupId);

		groupService.insertGroupGreeting(gvo);
		return "redirect:/group/groupDetail/?group_id=" + groupId;
	}
	@RequestMapping("/deleteGroupGreeting")
	@ResponseBody
    public String deleteGroupGreeting(GroupGreetingVO gvo, HttpSession session) {
	    String userId = (String) session.getAttribute("user_id");

	    if (userId == null || userId.isEmpty()) {
	        return "로그인이 필요합니다.";
	    }

	    GroupGreetingVO greetingInfo = groupService.getGroupGreeting(gvo);

	    if (greetingInfo == null) {
	        return "삭제할 인사말이 없습니다.";
	    }

	    if (!userId.equals(greetingInfo.getUser_id())) {
	        return "삭제 권한이 없습니다.";
	    }

	    groupService.deleteGroupGreeting(gvo);
	    return "삭제 완료";
	}
    @RequestMapping("/greetingList")
    @ResponseBody
    public List<GroupGreetingVO> getGroupGreetingList(@RequestParam("group_id") int groupId) {
        System.out.println(">>> greetingList 컨트롤러 실행됨");
        GroupGreetingVO gvo = new GroupGreetingVO();
        gvo.setGroup_id(groupId);
        return groupService.getGroupGreetingList(gvo);
    }
    
}