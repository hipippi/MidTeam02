package com.story.mosaic.repo;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AdminBoardDAO {
	//게시글 삭제(report_id)
	public int deletePostById(int post_id);
}
