package com.story.mosaic.repo;

import java.util.List;

import com.story.mosaic.model.AdminManagerVO;

public interface AdminManagerDAO {
	
	//관리자 등록 
	public void insertAdmin(AdminManagerVO vo);
	
	//관리자 목록 조회
	List<AdminManagerVO> getAdminList();
	
	//관리자 삭제 
	public void deleteAdmin(int admin_id);

	//공지사항 등록수 조회
	public int countNoticesByAdmin(int admin_id);
}
