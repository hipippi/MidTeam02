package com.story.mosaic.repo;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.annotations.Mapper;

import com.story.mosaic.model.GroupPartVO;
import com.story.mosaic.model.GroupGreetingVO;
import com.story.mosaic.model.GroupVO;

@Mapper
public interface GroupDAO {
	void insertGroup(GroupVO vo);
	List<GroupVO> getGroupList(HashMap map);
	GroupVO getGroup(GroupVO vo);
	void deleteGroup(GroupVO vo);
	void deleteGroupById(Integer group_id);
	void updateGroup(GroupVO vo);
	//group_tab
	
	void insertGroupPart(GroupPartVO pvo);
	GroupPartVO getGroupPart(GroupPartVO pvo);
	int deleteGroupPart(Integer part_id);
	void leaveGroupPart(GroupPartVO pvo);
	List<GroupPartVO> getGroupPartList(GroupPartVO pvo);
	//group_part
	
	void insertGroupGreeting(GroupGreetingVO gvo);
	GroupGreetingVO getGroupGreeting(GroupGreetingVO gvo);
	void deleteGroupGreeting(GroupGreetingVO gvo);
	List<GroupGreetingVO> getGroupGreetingList(GroupGreetingVO gvo);

}
