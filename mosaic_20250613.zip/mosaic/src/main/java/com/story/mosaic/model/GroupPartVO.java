package com.story.mosaic.model;

import lombok.Data;

@Data
public class GroupPartVO {
	private Integer part_id;
	private String user_id;
	private Integer group_id;
	private String part_status;
	private String nickname;
}
