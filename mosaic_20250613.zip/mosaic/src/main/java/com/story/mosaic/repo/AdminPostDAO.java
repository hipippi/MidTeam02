package com.story.mosaic.repo;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.story.mosaic.model.AdminPostVO;

@Mapper
public interface AdminPostDAO {
	
	// 타입별(story/group) 게시물 조회
	List<AdminPostVO> getPostsByType(@Param("type") String type);
	
    // 게시물 상태 업데이트 (공개 / 비공개)
    public void updateStatus(@Param("postId") int postId,
                      @Param("type") String type,
                      @Param("status") String status);

    public void deletePost(@Param("postId") int postId, @Param("type") String type);  // 게시물 삭제
    
    //스토리 마당 게시물수 조회
    public int getStoryPostCount();
    
    //모임 게시물 수 조회
    public int getGroupPostCount();
    
    // 모임 참가자 삭제 (group_part)
    public void deleteGroupPart(@Param("groupId") int groupId);

    // 모임 게시물 삭제 (group_tab)
    public void deleteGroup(@Param("groupId") int groupId);
}
