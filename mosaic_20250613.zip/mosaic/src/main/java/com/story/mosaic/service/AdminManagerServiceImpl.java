package com.story.mosaic.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.story.mosaic.model.AdminManagerVO;
import com.story.mosaic.repo.AdminManagerDAO;

//AdminManagerService 인터페이스 구현 클래스
@Service
public class AdminManagerServiceImpl implements AdminManagerService{
	
	@Autowired
	private AdminManagerDAO adminManagerDAO;
	
	//암호화
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;

	//관리자 등록
	@Override
	public void insertAdmin(AdminManagerVO vo) {
		// 사용자가 입력한 비밀번호 get
        String rawPassword = vo.getAdmin_password();

        // 암호화 진행
        String encPassword = passwordEncoder.encode(rawPassword);

        // 암호화된 비밀번호로 덮어쓰기
        vo.setAdmin_password(encPassword);

        // DAO를 통해 DB에 저장
        adminManagerDAO.insertAdmin(vo);
		
	}
	//관리자 목록 조회
	@Override
	public List<AdminManagerVO> getAdminList() {
	
		return adminManagerDAO.getAdminList();
	}
	//관리자 삭제
	@Override
	public void deleteAdmin(int admin_id) {
		adminManagerDAO.deleteAdmin(admin_id);
	}

	//공지사항 등록수 조회
	@Override
	public int countNoticesByAdmin(int admin_id) {
	    return adminManagerDAO.countNoticesByAdmin(admin_id);
	}
	
}
