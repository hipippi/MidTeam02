package com.story.mosaic.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NoticeVO {
	
	private int notice_id;
    private int admin_id;
    private String title;
    private String content;
    private String created_at;
    private int views;
    private String notice_type;
    private String admin_name;
}
