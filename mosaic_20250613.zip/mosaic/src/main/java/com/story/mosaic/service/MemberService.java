package com.story.mosaic.service;

import org.springframework.web.multipart.MultipartFile;

import com.story.mosaic.model.MemberVO;

public interface MemberService {
    // 로그인 관련
    MemberVO login(MemberVO vo);

    // 회원가입 관련
    void join(MemberVO vo);

    // 프로필 이미지 저장
    String saveProfileImage(MultipartFile file, String uploadPath) throws Exception;

    // 중복 체크
    boolean idCheck(String email);
    boolean nicknameCheck(String nickname);
    
    //user_id로 회원 조회
    MemberVO findByUserId(String userId);
    
    // SNS 회원 가입
    String registerSnsUser(String email, String nickname);
}
