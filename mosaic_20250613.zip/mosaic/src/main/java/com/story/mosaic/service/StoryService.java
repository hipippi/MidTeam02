package com.story.mosaic.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.ui.Model;

import com.story.mosaic.model.LocationVO;
import com.story.mosaic.model.ScheduleVO;
import com.story.mosaic.model.StoryVO;
import com.story.mosaic.model.CommentVO;


public interface StoryService {
	
	void selectStoryView(StoryVO vo, LocationVO lo, ScheduleVO so, Model model);
	void insertStory(StoryVO vo, LocationVO lo, ScheduleVO so);
	void updateStory(StoryVO vo, LocationVO lo, ScheduleVO so);
	void deleteStory(StoryVO vo, LocationVO lo, ScheduleVO so);
	
	// 목록 조회
	List<StoryVO> getStoriesByCategories(List<String> categories);
	List<String> getCategoryList();
	List<StoryVO> getStoryList(HashMap map);	
	
	// 페이징
	int getStoryCount(Map<String, Object> map);
	List<StoryVO> getPagedStoryList(Map<String, Object> map);
	
	// 조회수 증가
	void increaseViewCount(StoryVO vo);
}
