package com.story.mosaic.repo;

import org.apache.ibatis.annotations.Mapper;

import com.story.mosaic.model.AdminGroupVO;
@Mapper
public interface AdminGroupDAO {
	
    // 특정 group_id에 해당하는 모임 상세정보 조회 (관리자용)
    AdminGroupVO getAdminGroupById(int group_id);

}
