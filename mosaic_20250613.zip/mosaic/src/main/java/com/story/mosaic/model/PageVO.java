package com.story.mosaic.model;

import lombok.Data;

@Data
public class PageVO {
    private int page = 1;       // 현재 페이지
    private int size = 10;      // 페이지당 게시글 수
    private int totalCount;     // 전체 게시글 수
    private int totalPages;     // 전체 페이지 수

    private int startRow;       // Oracle용 시작 row
    private int endRow;         // Oracle용 끝 row

    private int blockSize = 5;  // 블록당 페이지 수
    private int startPage;      // 현재 블록 시작 페이지
    private int endPage;        // 현재 블록 끝 페이지

    private boolean hasPrevBlock;
    private boolean hasNextBlock;

    public void calculate() {
        totalPages = (int) Math.ceil((double) totalCount / size);
        startRow = (page - 1) * size + 1;
        endRow = page * size;

        startPage = ((page - 1) / blockSize) * blockSize + 1;
        endPage = Math.min(startPage + blockSize - 1, totalPages);

        hasPrevBlock = startPage > 1;
        hasNextBlock = endPage < totalPages;
    }

    // Getters & Setters 생략
}