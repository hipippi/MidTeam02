package com.story.mosaic.model;


import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class AdminGroupVO {
	private Integer group_id;
	private String group_title;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date group_date;
	private String group_content;
	private String user_id;
	private String group_image; //파일명
	private String group_irealname; //저장된 파일이름
	private String group_isize; //파일크기 --오류떠서 string으로 변환
	
	private String status; // 추가: 공개/비공개 구분
	private int group_views; // 추가: 모임 조회수
}
