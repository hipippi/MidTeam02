package com.story.mosaic.service;

import com.story.mosaic.model.AdminGroupVO;

public interface AdminGroupService {

    AdminGroupVO getGroupDetail(int group_id);
}
