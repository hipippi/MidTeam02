package com.story.mosaic.repo;

import org.apache.ibatis.annotations.Mapper;

import com.story.mosaic.model.LocationVO;

@Mapper	
public interface LocationDAO {
    LocationVO selectLocation(LocationVO lo);
	void insertLocation(LocationVO lo);	
	void updateLocation(LocationVO lo);
    void deleteLocation(LocationVO lo);
}