package com.story.mosaic.util;

import java.util.HashMap;
import java.util.Map;

public class MapUtils {
    public static Map<String, String> toLowerKeyMap(Map<String, String> original) {
        Map<String, String> lowerKeyMap = new HashMap<>();
        for (Map.Entry<String, String> entry : original.entrySet()) {
            lowerKeyMap.put(entry.getKey().toLowerCase(), entry.getValue());
        }
        return lowerKeyMap;
    }
}
