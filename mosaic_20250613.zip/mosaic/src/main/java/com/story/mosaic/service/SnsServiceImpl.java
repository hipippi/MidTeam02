package com.story.mosaic.service;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.story.mosaic.model.MemberVO;
import com.story.mosaic.model.SnsVO;
import com.story.mosaic.repo.MemberDAO;
import com.story.mosaic.repo.SnsDAO;

@Service
public class SnsServiceImpl implements SnsService {

	
	 @Autowired
	    private SnsDAO snsDAO;

	    @Override
	    public void saveRandomId(String kakaoId, String nickname, String randomId) {
	        snsDAO.saveRandomId(kakaoId, nickname, randomId);
	    }
	
//    private final SnsDAO snsDAO;
//    private final MemberDAO memberDAO;
//
//    @Autowired
//    public SnsServiceImpl(SnsDAO snsDAO, MemberDAO memberDAO) {
//        this.snsDAO = snsDAO;
//        this.memberDAO = memberDAO;
//    }
//
//    @Override
//    public void saveSnsLink(SnsVO snsVO) {
//        snsDAO.insert(snsVO);
//    }
//
//    @Override
//    public SnsVO findBySnsIdAndPlatform(String snsId, String platform) {
//        return snsDAO.findBySnsIdAndPlatform(snsId, platform);
//    }
//
//    @Override
//    public SnsVO findByUserId(String userId) {
//        return snsDAO.getByUserId(userId);
//    }
//
//    @Override
//    public void deleteSnsLink(String userId, String platform) {
//    	SnsVO snsVO = new SnsVO();
//    	snsVO.setUser_id(userId);       // userId가 아니라 user_id 필드에 세팅
//    	snsVO.setSns_platform(platform);
//    	snsDAO.delete(snsVO);
//
//    }
//
//
//    @Override
//    public MemberVO registerSnsUser(SnsVO snsVO) {
//        // 1. 이메일로 기존 회원 조회
//        MemberVO existing = memberDAO.findByEmail(snsVO.getEmail());
//        if (existing != null) {
//            return existing;
//        }
//
//        // 2. 유일한 user_id 생성
//        String userId;
//        do {
//            userId = UUID.randomUUID().toString().replace("-", "").substring(0, 20);
//        } while (memberDAO.existsUserId(userId) > 0);
//
//        // 3. 새 사용자 정보 구성
//        MemberVO newMember = new MemberVO();
//        newMember.setUser_id(userId);
//        newMember.setEmail(snsVO.getEmail());
//        newMember.setPassword("SNS"); // 의미 없음
//        newMember.setNickname(snsVO.getNickname());
//        newMember.setName("SNS");
//        newMember.setNationality("SNS");
//        newMember.setCity("SNS");
//        newMember.setSns_id(snsVO.getSns_id());
//        newMember.setUser_img(snsVO.getUser_img());
//
//        // 4. DB에 삽입
//        memberDAO.insertSnsMember(newMember);
//
//        // 5. SNS 연동 테이블 저장
//        SnsVO link = new SnsVO();
//        link.setSns_id(snsVO.getSns_id());
//        link.setSns_platform(snsVO.getSns_platform());
//        link.setUser_id(userId);
//        snsDAO.insert(link);
//
//        return newMember;
//    }
}
