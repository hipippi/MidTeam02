package com.story.mosaic.repo;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.story.mosaic.model.VisitorLogVO;

//이 인터페이스는 visitor_log 테이블에 접근하는 DAO 역할을 한다
//@Mapper 어노테이션 덕분에 MyBatis가 XML과 자동으로 연결해준다

@Mapper
public interface VisitorLogDAO {
	
    // 방문자 정보를 DB에 저장하는 메서드
    // VisitorLogVO에 담긴 IP, 페이지 주소 등을 INSERT할 때 사용됨
	public void insertVisitorLog(VisitorLogVO vo); // 방문자 정보를 DB에 저장 (VisitorLogVO로부터 IP, 페이지 정보 받음)

	//주,월,연도별 방문자 수 통계
	public List<Map<String, Object>> getMonthlyVisitorStats();
	public List<Map<String, Object>> getWeeklyVisitorStats();
	public List<Map<String, Object>> getYearlyVisitorStats();
	
	public List<VisitorLogVO> getVisitorStatsByWeek(String month);
}
