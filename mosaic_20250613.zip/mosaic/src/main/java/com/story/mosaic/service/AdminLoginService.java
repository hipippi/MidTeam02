package com.story.mosaic.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.story.mosaic.model.AdminLoginVO;

@Service
public interface AdminLoginService {
	//이메일이랑 비밀번호를 파라매터로 받음
	 AdminLoginVO login(String email, String password);
}
