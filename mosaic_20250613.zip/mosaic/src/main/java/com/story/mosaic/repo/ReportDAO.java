package com.story.mosaic.repo;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.story.mosaic.model.ReportVO;

@Mapper
public interface ReportDAO {
	//신고 목록 조회 
	public List<ReportVO> getReportList();

	//신고 처리 
	public int updateReportStatus(ReportVO vo);
}
