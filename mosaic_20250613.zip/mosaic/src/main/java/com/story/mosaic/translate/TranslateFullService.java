package com.story.mosaic.translate;

public interface TranslateFullService {
    String translate(String text, String targetLang);
}