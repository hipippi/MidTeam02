package com.story.mosaic.model;

import lombok.Data;
import java.util.Date;

@Data
public class AdminPostVO {
    private int postId;         // 게시물 ID
    private String title;       // 제목
    private String userId;      // 작성자 ID
    private String writeDate;     // 작성일
    private int views;          // 조회수
    private String status;      // '정상', '비공개', '삭제'
    private String type;        // 'story' 또는 'group'
}
