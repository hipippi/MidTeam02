package com.story.mosaic.model;

import lombok.Data;

@Data
public class SnsVO {
    private String sns_id;       // 연동 ID (서비스 사용자 ID)
    private String user_id;      // 회원 ID (FK, USER000001 같은 문자열)
    private String sns_platform; // 플랫폼 연동 카테고리
    
    private String email;          // 이메일 추가
    private String nickname;       // 닉네임 추가
    private String user_img;       // 프로필 이미지 추가
}
