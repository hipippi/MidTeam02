package com.story.mosaic.service;

import java.util.List;

import com.story.mosaic.model.VisitorLogVO;

public interface VisitorLogService {
	 // 방문자 정보를 DB에 저장
	public void insertVisitorLog(VisitorLogVO vo);
	
	// 한달 기준 방문자 통계수  
    public List<VisitorLogVO> getVisitorStatsByWeek(String month);
}
