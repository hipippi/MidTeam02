package com.story.mosaic.model;

import java.util.Date;
import lombok.Data;

@Data
public class CommentVO {
    private Integer 	comment_id;
    private Integer 	post_id;
    private String 		user_id;
    private String 		content;
    private Date 		created_at;
    
    //comment 객체에만 있음. comment table에는 없고 user table
    private String 		user_img;   
    private String 		nickname;	 // 작성자 닉네임 추가
}