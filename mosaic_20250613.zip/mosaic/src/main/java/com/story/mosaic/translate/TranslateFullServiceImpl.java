package com.story.mosaic.translate;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import org.json.JSONObject;
import org.springframework.stereotype.Service;

@Service
public class TranslateFullServiceImpl implements TranslateFullService {
	
    private static final String API_URL = "https://api-free.deepl.com/v2/translate";
    private static final String AUTH_KEY = "636ec227-8bf2-4b8e-8546-a2b48f0e04f5:fx";
    
    public String translate(String text, String targetLang) {
        try {
            String data = "auth_key=" + URLEncoder.encode(AUTH_KEY, "UTF-8") +
                          "&text=" + URLEncoder.encode(text, "UTF-8") +
                          "&target_lang=" + URLEncoder.encode(targetLang, "UTF-8") +
                          "&tag_handling=html";

            System.out.println("Full data: " + data);

            URL url = new URL(API_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

            // ✅ 먼저 요청 본문을 보낸다
            try (OutputStream os = conn.getOutputStream()) {
                os.write(data.getBytes(StandardCharsets.UTF_8));
            }

            // ✅ 그 다음 응답코드를 확인한다
            int responseCode = conn.getResponseCode();
            System.out.println("DEEPL 응답 코드: " + responseCode);

            if (responseCode == 200) {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) {
                        response.append(line);
                    }
                    JSONObject json = new JSONObject(response.toString());
                    return json.getJSONArray("translations").getJSONObject(0).getString("text");
                }
            } else {
                System.err.println("DeepL 요청 실패 - 응답 코드: " + responseCode);
                try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8))) {
                    StringBuilder errorResponse = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) {
                        errorResponse.append(line);
                    }
                    System.err.println("DeepL 오류 내용: " + errorResponse.toString());
                }
                return "[DeepL 요청 실패: HTTP " + responseCode + "]";
            }

        } catch (Exception e) {
            e.printStackTrace();
            return "[Translate Failed in TranslateFullService]";
        }
    }

    
    /*
    public String translate(String text, String targetLang) {
        try {
            String data = "auth_key=" + URLEncoder.encode(AUTH_KEY, "UTF-8") +
                          "&text=" + URLEncoder.encode(text, "UTF-8") +
                          "&target_lang=" + URLEncoder.encode(targetLang, "UTF-8") +            
				          "&tag_handling=html";
				            
				            
            System.out.println("full data "+ data);
            URL url = new URL(API_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            
            
          //deepL 응답 코드
            int responseCode = conn.getResponseCode();
            System.out.println("DEEPL 응답 코드: " + responseCode);
            
            try (OutputStream os = conn.getOutputStream()) {
                os.write(data.getBytes(StandardCharsets.UTF_8));
            }

            try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) {
                    response.append(line);
                }
                JSONObject json = new JSONObject(response.toString());
                return json.getJSONArray("translations").getJSONObject(0).getString("text");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "[Translate Failed in TranslateFullService]";
        }
    }
*/
}
