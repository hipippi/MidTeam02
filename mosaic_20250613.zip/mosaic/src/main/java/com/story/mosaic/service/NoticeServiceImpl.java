package com.story.mosaic.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.story.mosaic.model.NoticeVO;
import com.story.mosaic.repo.NoticeDAO;

//Spring이 이 클래스를 서비스 컴포넌트로 등록하게 해주는 어노테이션
@Service
public class NoticeServiceImpl implements NoticeService {
	 // NoticeDAO를 자동으로 주입받아 DB 작업을 처리함
	@Autowired
	private NoticeDAO noticeDAO;

	@Override
	public List<NoticeVO> getNoticeList() {
		// noticeDAO를 호출해서 DB에서 공지사항 데이터를 조회
		return noticeDAO.getNoticeList();
	}

	@Override
	public void insertNotice(NoticeVO vo) {
		//DB에 insert
		noticeDAO.insertNotice(vo); 
		
	}
	//공지사항 상세보기
	@Override
	public NoticeVO getNoticeById(int notice_id) {
		
		return noticeDAO.getNoticeById(notice_id);
	}
	//공지사항 수정
	@Override
	public void updateNotice(NoticeVO vo) {
		//DAO에게 vo를 넘겨서 업데이트
		noticeDAO.updateNotice(vo);
	}

	@Override
	public void deleteNotice(int notice_id) {
		// DAO 를 호출하여 해당id 공지사항 게시물 삭제 
		noticeDAO.deleteNotice(notice_id);
	}

	@Override
	public void increaseViews(int notice_id) {
		// 조회수 증가 요청이 들어오면 DAO에게 전달하여 DB 값 증가
		noticeDAO.increaseViews(notice_id);
	}

	@Override
	public List<NoticeVO> getRecentNotices() {
		 // DAO의 getRecentNotices() 호출해서 결과 리턴
		return noticeDAO.getRecentNotices();
	}

	//공지사항 카테고리 검색 오버라이드
	@Override
	public List<NoticeVO> searchNotices(String keyword, String noticeType) {
		
		return noticeDAO.searchNotices(keyword, noticeType);
	}
	
	
	

}
