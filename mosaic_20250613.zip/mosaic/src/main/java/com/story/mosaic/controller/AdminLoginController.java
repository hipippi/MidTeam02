package com.story.mosaic.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.story.mosaic.model.AdminLoginVO;
import com.story.mosaic.service.AdminLoginService;

@Controller
@RequestMapping("/admin")
public class AdminLoginController {

    @Autowired
    private AdminLoginService loginService;

    // 로그인 폼 보여주기
    @GetMapping("/login")
    public String showLoginForm() {
    	return "admin/AdminLogin";  
    }

    // 로그인 처리
    @PostMapping("/loginCheck")
    public String loginCheck(@RequestParam String email,
                             @RequestParam String password,
                             HttpSession session,
                             Model model) {

        // 서비스에서 로그인 처리
        AdminLoginVO admin = loginService.login(email, password);

        if (admin != null) {
            // 로그인 성공했을때 세션에 관리자 정보 저장
            session.setAttribute("adminLogin", admin);
            return "redirect:/admin/adminMain"; // 관리자 메인페이지로 이동
        } else {
            //  로그인 실패
            model.addAttribute("loginError", "등록되지 않은 계정이거나 비밀번호가 일치하지 않습니다.");
            return "admin/AdminLogin"; // 로그인 JSP로 다시 이동
        }
    }

    // 로그아웃 처리 
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        // 세션 전체 초기화 (모든 세션 속성 제거)
        session.invalidate();
        // 관리자 로그인 페이지로 리다이렉트
        return "redirect:/admin/login";
    }
}
