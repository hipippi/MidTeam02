package com.story.mosaic.repo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.story.mosaic.model.StoryVO;
//import com.story.mosaic.model.LocationVO;
//import com.story.mosaic.model.ScheduleVO;

@Mapper	
public interface StoryDAO {
    StoryVO selectStory(StoryVO vo);
    void insertStory(StoryVO vo);
    void updateStory(StoryVO vo);
    void deleteStory(StoryVO vo);
    
    // 조회수 증가
    void increaseViewCount(StoryVO vo);
    
    // 목록 조회
    List<String> getCategoryList();
    List<StoryVO> getStoriesByCategories(List<String> categories);
    List<StoryVO> getStoryList(HashMap map);
    
    // 페이징
    int getStoryCount(Map<String, Object> map);
    List<StoryVO> getPagedStoryList(Map<String, Object> map);
}