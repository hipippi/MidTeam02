package com.story.mosaic.service;

import java.util.List;

import com.story.mosaic.model.NoticeVO;

public interface NoticeService {
	// 공지사항 목록을 db에서 조회
	public List<NoticeVO> getNoticeList();
	
	// 공지사항 등록
	public void insertNotice(NoticeVO vo);
	
	// 공지사항 상세 조회 
	public NoticeVO getNoticeById(int notice_id);
	
	// 공지사항 수정
	public void updateNotice(NoticeVO vo);
	
	//공지사항 삭제
	public void deleteNotice(int notice_id);
	
	//조회수 증가
	public void increaseViews(int notice_id);
	
	//최신 공지사항
	public List<NoticeVO> getRecentNotices();
	
	//공지사항 카테고리 검색
	public List<NoticeVO> searchNotices(String keyword, String noticeType);
}


