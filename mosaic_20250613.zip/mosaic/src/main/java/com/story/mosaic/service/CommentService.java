package com.story.mosaic.service;

import java.util.List;

import com.story.mosaic.model.CommentVO;

public interface CommentService {
    void insertComment(CommentVO vo);
    void updateComment(CommentVO vo);
    void deleteComment(CommentVO vo);
    
    
    List<CommentVO> getCommentsByPostId(Integer post_id);
    List<CommentVO> getCommentsByPostIdPaged(Integer post_id, int page, int pageSize);
    int countCommentsByPostId(Integer post_id);
    void deleteCommentsByPostId(Integer post_id);

}
