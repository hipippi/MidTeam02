package com.story.mosaic.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.story.mosaic.model.AdminReportVO;
import com.story.mosaic.service.AdminBoardService;
import com.story.mosaic.service.AdminReportService;

@Controller
@RequestMapping("/admin")
public class AdminReportController {
	//신고처리 관련 서비스
	@Autowired
	private AdminReportService reportService;
	//게시글 삭제처리 관련 서비스
	@Autowired
	private AdminBoardService adminBoardService;
	
	@GetMapping("/reportList")
	public String reportList(Model model) {
		//신고 목록 조회
		List<AdminReportVO> list = reportService.getReportList();
		
		model.addAttribute("reportList", list);
		
		return "admin/reportList";
	}
	//신고처리 상태
	@PostMapping("/processReport")
	public String processReport(@RequestParam("report_id") int report_id) {
		AdminReportVO vo = new AdminReportVO();
		
		vo.setReport_id(report_id);
		vo.setStatus("완료");
		
		reportService.updateReportStatus(vo);
		
		return "redirect:/admin/reportList";
		
	}
	//게시글 삭제 , 신고처리 상태
	@PostMapping("/deletePostAndProcess")
	public String deletePostAndProcess(@RequestParam("report_id") int report_id,
									   @RequestParam("post_id")int post_id) {
		//게시글 삭제
		adminBoardService.deletePostById(post_id);
		//신고 상태 "완료"로 변경
		AdminReportVO vo = new AdminReportVO();
		vo.setReport_id(report_id);
		vo.setStatus("완료");
		reportService.updateReportStatus(vo);
		
		return "redirect:/admin/reportList";
	}
	
}
