package com.story.mosaic.model;

import java.sql.Date;

import lombok.Data;

@Data
public class AdminLoginVO {

	private int admin_id;
	private String admin_name;
	private String admin_email;
	private String admin_level;
	private String admin_password;
	private Date created_at;
}
